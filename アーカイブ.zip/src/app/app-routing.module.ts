import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ServiceOverviewPageComponent } from './pages/introduction/service-overview-page/service-overview-page.component';
import { ServiceTermsAgreementPageComponent } from './pages/introduction/service-terms-agreement-page/service-terms-agreement-page.component';
import { AccountLinkAgreementPageComponent } from './pages/introduction/account-link-agreement-page/account-link-agreement-page.component';

const routes: Routes = [
  { path: '', redirectTo: '/service-overview', pathMatch: 'full' },
  { path: 'service-overview', component: ServiceOverviewPageComponent },
  {
    path: 'service-terms-agreement',
    component: ServiceTermsAgreementPageComponent,
  },
  {
    path: 'account-link-agreement',
    component: AccountLinkAgreementPageComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
