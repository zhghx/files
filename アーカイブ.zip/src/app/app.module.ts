import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceOverviewPageComponent } from './pages/introduction/service-overview-page/service-overview-page.component';
import { ServiceTermsAgreementPageComponent } from './pages/introduction/service-terms-agreement-page/service-terms-agreement-page.component';
import { AccountLinkAgreementPageComponent } from './pages/introduction/account-link-agreement-page/account-link-agreement-page.component';

import { IonicModule } from '@ionic/angular';
import { ButtonPrimaryComponent } from './components/button/button-primary/button-primary.component';

// SwiperModule
import { SwiperModule } from 'swiper/angular';
import { CarouselComponent } from './components/carousel/carousel.component';

@NgModule({
  declarations: [
    AppComponent,
    ServiceOverviewPageComponent,
    ServiceTermsAgreementPageComponent,
    AccountLinkAgreementPageComponent,
    ButtonPrimaryComponent,
    CarouselComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    IonicModule.forRoot(),
    SwiperModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
