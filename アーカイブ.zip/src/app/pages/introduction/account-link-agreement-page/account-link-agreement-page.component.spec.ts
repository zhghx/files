import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountLinkAgreementPageComponent } from './account-link-agreement-page.component';

describe('AccountLinkAgreementPageComponent', () => {
  let component: AccountLinkAgreementPageComponent;
  let fixture: ComponentFixture<AccountLinkAgreementPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountLinkAgreementPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountLinkAgreementPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
