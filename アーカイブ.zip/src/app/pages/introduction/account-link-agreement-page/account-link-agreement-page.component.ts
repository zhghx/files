import { Component } from '@angular/core';

@Component({
  selector: 'app-account-link-agreement-page',
  templateUrl: './account-link-agreement-page.component.html',
  styleUrls: ['./account-link-agreement-page.component.scss'],
})
export class AccountLinkAgreementPageComponent {}
