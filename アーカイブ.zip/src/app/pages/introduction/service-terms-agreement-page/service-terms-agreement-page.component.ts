import { Component } from '@angular/core';

@Component({
  selector: 'app-service-terms-agreement-page',
  templateUrl: './service-terms-agreement-page.component.html',
  styleUrls: ['./service-terms-agreement-page.component.scss'],
})
export class ServiceTermsAgreementPageComponent {}
