import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceTermsAgreementPageComponent } from './service-terms-agreement-page.component';

describe('ServiceTermsAgreementPageComponent', () => {
  let component: ServiceTermsAgreementPageComponent;
  let fixture: ComponentFixture<ServiceTermsAgreementPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServiceTermsAgreementPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceTermsAgreementPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
