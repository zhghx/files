import { Component } from '@angular/core';

@Component({
  selector: 'app-service-overview-page',
  templateUrl: './service-overview-page.component.html',
  styleUrls: ['./service-overview-page.component.scss'],
})
export class ServiceOverviewPageComponent {}
