import {
  Component,
  OnInit,
  AfterViewInit,
  Input,
  ChangeDetectorRef,
  NgZone,
  ElementRef,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { SwiperComponent } from 'swiper/angular';
import Swiper from 'swiper/types/swiper-class';
import { BehaviorSubject } from 'rxjs';

// import Swiper core and required components
import SwiperCore, {
  Navigation,
  Pagination,
  Scrollbar,
  A11y,
  Virtual,
  Zoom,
  Autoplay,
  Thumbs,
  Controller,
} from 'swiper';

// install Swiper components.
SwiperCore.use([
  Navigation,
  Pagination,
  Scrollbar,
  A11y,
  Virtual,
  Zoom,
  Autoplay,
  Thumbs,
  Controller,
]);

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
})
export class CarouselComponent implements OnInit {
  @ViewChild('swiperRef', { static: false }) swiperRef?: SwiperComponent;

  data: any;

  isEnd: boolean;

  constructor(
    private router: Router,
    private cd: ChangeDetectorRef,
    private ngZone: NgZone
  ) {}

  ngOnInit(): void {
    this.data = [
      {
        name: '1',
      },
      {
        name: '2',
      },
      {
        name: '3',
      },
      {
        name: '4',
      },
      {
        name: '5',
      },
    ];
  }

  onSwiper() {
    console.log('init');
  }

  onSlideChange(swiper: any) {
    this.isEnd = swiper[0].isEnd;
  }

  toBtn = () => {
    if (this.isEnd) {
      this.router.navigate(['service-terms-agreement']);
    } else {
      if (this.swiperRef) {
        this.swiperRef.swiperRef.slideNext(300);
        this.isEnd = this.swiperRef.swiperRef.isEnd;
        console.log(this.swiperRef.swiperRef.isEnd);
      }
    }
  };
}
