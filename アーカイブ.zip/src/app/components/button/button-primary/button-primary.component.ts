import { Component } from '@angular/core';

@Component({
  selector: 'app-button-primary',
  templateUrl: './button-primary.component.html',
  styleUrls: ['../button-common.scss', './button-primary.component.scss'],
})
export class ButtonPrimaryComponent {}
