'use strict';

var proxyquire = require('proxyquire').noCallThru().noPreserveCache();

function proxyModel() {
    return proxyquire('../../../cartridges/int_mps/cartridge/scripts/service/mpsAddPointService', {
        '*/cartridge/scripts/util/mpsLogger': {},
        '*/cartridge/scripts/util/mpsDateFormat': {},
        '*/cartridge/scripts/service/mock/mpsCustomerAuth.js': {}
    });
}

module.exports = proxyModel();
