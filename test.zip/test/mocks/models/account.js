'use strict';

var proxyquire = require('proxyquire').noCallThru().noPreserveCache();
var mockSuperModule = require('../mockModuleSuperModule');
var baseAccountMock = require('../scripts/checkout/baseAccount');

var URLUtils = {
    url: function () {
        return 'some url';
    },
    https: function () {
        return 'some url';
    },
    staticURL: function () {
        return 'some staticURL';
    }
};

function proxyModel() {
    mockSuperModule.create(baseAccountMock);
    return proxyquire('../../../cartridges/int_mps_sfra/cartridge/models/account', {
        'dw/web/URLUtils': URLUtils,
        '*/cartridge/models/address': {}
    });
}

module.exports = proxyModel();
