'use strict';

function account() {
}

module.exports = account;
