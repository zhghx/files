'use strict';

function Payment() {
}

module.exports = Payment;
