﻿'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();


function proxyModel() {
    return proxyquire('../../../../cartridges/int_mps_sfra/cartridge/scripts/models/AddressModel', {
        './AbstractModel': require('../../../mocks/scripts/models/AbstractModel'),
        'dw/customer/ProductListMgr': {},
        'dw/system/Transaction': {},
        '~/cartridge/scripts/models/FormModel': {}
    });
}

module.exports = proxyModel();

