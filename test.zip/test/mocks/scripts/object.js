'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();

function HashMap() {
    return {
        element: [],
        entrySet: function () {
            return this.element;
        },
        put: function () {
        }
    };
}

function proxyModel() {
    return proxyquire('../../../cartridges/int_mps_sfra/cartridge/scripts/object', {
        'dw/util/HashMap': HashMap
    });
}

module.exports = proxyModel();

