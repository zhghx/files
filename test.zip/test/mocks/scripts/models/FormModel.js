﻿'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();


function proxyModel() {
    return proxyquire('../../../../cartridges/int_mps_sfra/cartridge/scripts/models/FormModel', {
        './AbstractModel': require('../../../mocks/scripts/models/AbstractModel'),
        '~/cartridge/scripts/object':require('../../../../cartridges/int_mps_sfra/cartridge/scripts/object')
    });
}

module.exports = proxyModel();

