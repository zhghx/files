'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();

var Class = require('../../../../cartridges/int_mps_sfra/cartridge/scripts/util/Class');

var Logger = {
    warn: function (msg) {
        console.log(msg);
    },
    info: function (msg) {
        console.log(msg);
    },
    error: function (msg) {
        console.log(msg);
    }
};

function proxyModel() {
    return proxyquire('../../../../cartridges/int_mps_sfra/cartridge/scripts/models/AbstractModel', {
        '~/cartridge/scripts/util/Class': Class,
        'dw/system/Logger': Logger
    });
}

module.exports = proxyModel();
