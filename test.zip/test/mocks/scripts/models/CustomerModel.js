﻿'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();


function proxyModel() {
    return proxyquire('../../../../cartridges/int_mps_sfra/cartridge/scripts/models/CustomerModel', {
        '*/cartridge/scripts/models/AbstractModel': require('../../../mocks/scripts/models/AbstractModel'),
        'dw/customer/CustomerMgr': {},
        'dw/system/Transaction': {},
        '*/cartridge/scripts/models/FormModel': {}
    });
}

module.exports = proxyModel();

