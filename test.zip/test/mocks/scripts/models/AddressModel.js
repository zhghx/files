'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();

let Transaction = {
    wrap: function (fun) {
        fun.call();
    }
};

let Form = {
    value: null,
    get: function (addressForm) {
        this.value = addressForm;
        return this;
    },
    copyTo: function (address) {
        if (!this.value) {
            return null;
        }
        if (address) {
            address = this.value;
            return address;
        }
        return null;
    }
};

function proxyModel() {
    return proxyquire('../../../../cartridges/int_mps_sfra/cartridge/scripts/models/AddressModel', {
        './AbstractModel': require('../../../mocks/scripts/models/AbstractModel'),
        'dw/customer/ProductListMgr': {},
        'dw/system/Transaction': Transaction,
        '~/cartridge/scripts/models/FormModel': Form
    });
}

module.exports = proxyModel();

