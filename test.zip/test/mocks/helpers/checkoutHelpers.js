'use strict';


var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();

var collections = require('../util/collections');
var addressModel = require('../models/address');
var orderModel = require('../models/order');

var renderTemplateHelper = require('./renderTemplateHelper');
var shippingHelpers = require('./shippingHelpers');
var basketMgr = require('../dw/order/BasketMgr');


var server = {
    forms: {
        getForm: function (formName) {
            return {
                formName: formName,
                clear: function () {
                }
            };
        }
    }
};

var transaction = {
    wrap: function (callBack) {
        return callBack.call();
    },
    begin: function () {
    },
    commit: function () {
    }
};

var hookMgr = {
    callHook: function () {
    }
};

var resource = {
    msg: function (param1) {
        return param1;
    }
};

var status = {
    OK: 0,
    ERROR: 1
};

var orderMgr = {
    createOrder: function () {
        return { order: 'new order' };
    },
    placeOrder: function () {
        return status.OK;
    },
    failOrder: function () {
        return { order: 'failed order' };
    }
};

var order = {
    CONFIRMATION_STATUS_NOTCONFIRMED: 'ONFIRMATION_STATUS_NOTCONFIRMED',
    CONFIRMATION_STATUS_CONFIRMED: 'CONFIRMATION_STATUS_CONFIRMED',
    EXPORT_STATUS_READY: 'order export status is ready'
};

function StrObj(value) {
    this.value = value;
    this.equals = function (param) {
        return param === this.value;
    };
}

function proxyModel() {
    return proxyquire('../../../cartridges/int_mps_sfra/cartridge/scripts/checkout/checkoutHelpers', {
        'server': server,
        '*/cartridge/scripts/util/collections': collections,
        '*/cartridge/scripts/helpers/basketCalculationHelpers': {
            calculateTotals: function () {
            }
        },

        'dw/order/BasketMgr': basketMgr,
        'dw/util/HashMap': {},
        'dw/system/HookMgr': hookMgr,
        'dw/net/Mail': {},
        'dw/order/OrderMgr': orderMgr,
        'dw/order/PaymentInstrument': {
            METHOD_GIFT_CERTIFICATE: new StrObj('test')
        },
        'dw/order/PaymentMgr': {
            getPaymentMethod: function () {
                return {
                    getApplicablePaymentCards: function (param) {
                        return param;
                    },
                    getPaymentProcessor: function () {
                        return {
                            ID: {
                                toLowerCase: function () {
                                    return '';
                                }
                            }
                        };
                    }
                };
            },
            getApplicablePaymentMethods: function () {
                return {
                    contains: function () {

                    }
                };
            }
        },
        'dw/order/Order': order,
        'dw/system/Status': status,
        'dw/web/Resource': resource,
        'dw/system/Site': {
            current: {
                getCustomPreferenceValue: function () {
                    return {};
                }
            }
        },
        'dw/util/Template': {},
        'dw/system/Transaction': transaction,
        'dw/util/Locale': {
            getLocale: function (locale) {
                return {
                    country: 'JP'
                };
            }
        },

        '*/cartridge/models/address': addressModel,
        '*/cartridge/models/order': orderModel,
        '*/cartridge/scripts/helpers/emailHelpers': {
            sendEmail: function () {

            },
            emailTypes: {
                orderConfirmation: ''
            }
        },
        '*/cartridge/scripts/renderTemplateHelper': {
            getRenderedHtml: function () {

            }
        },
        '*/cartridge/scripts/checkout/shippingHelpers': shippingHelpers,
        '*/cartridge/scripts/formErrors': require('../../../../storefront-reference-architecture/cartridges/app_storefront_base/cartridge/scripts/formErrors')
    });
}

module.exports = proxyModel();
