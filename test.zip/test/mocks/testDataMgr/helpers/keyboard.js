/**
 * This module provides the unicode values for keyboard keys
 */

export const TAB = '\uE004';
export const DOWN = '\ue015';
export const RIGHT = '\ue014';
export const ENTER = '\ue007';
