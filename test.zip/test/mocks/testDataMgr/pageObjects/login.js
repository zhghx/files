'use strict';

export const createAccountTab = '.login-form-nav .nav-item:nth-child(2)';
export const logInTab = '.login-form-nav .nav-item:nth-child(1)';
export const createAccountButton = '#register .btn-primary';
export const getRegisterFormFeedback = '#register .form-control-feedback';
export const getTrackOrderFormFeedback = '.trackorder .form-control-feedback';
export const checkStatusButton = '.trackorder .btn-primary';
