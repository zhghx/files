﻿'use strict';

var assert = require('chai').assert;

var FormModel = require('../../../../mocks/scripts/models/FormModel');

var obj = {
    name: 'test code'
};

describe('FormModel Unit Test', function () {
    it('test 1', function () {
        let formModel = new FormModel(obj);
    });
});

