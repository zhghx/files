﻿'use strict';

var { assert, expect } = require('chai');

var FormModel = require('../../../../mocks/scripts/models/FormModel');

var obj = {
    name: 'test code'
};

function setGlobal() {
    global.session = {
        forms: ''
    };
    global.request = {
        triggeredFormAction: {
            action: {
                formId: ''
            }
        }
    };
    global.dw = {
        system: {
            Logger: {
                warn: function () {

                },
                error: function () {

                }
            }
        }
    };
}

function setGlobal2() {
    global.session = {
        forms: ''
    };
    global.request = {
        triggeredFormAction: {
            formId: '100'
        }
    };
    global.dw = {
        system: {
            Logger: {
                warn: function () {

                },
                error: function () {

                }
            },
            Transaction: function () {
                return {
                    wrap: function (fun) {
                        fun.call();
                    }
                };
            }
        }
    };
}


describe('FormModel Unit Test', function () {
    it('test get normal', function () {
        setGlobal();
        let formReference = {};
        FormModel.get(formReference);
    });

    it('test get normal require', function () {
        setGlobal();
        let formReference = '{"a":1}';
        FormModel.get(formReference);
    });

    it('test get obj normal', function () {
        setGlobal();
        let obj = {};
        let groupName = '';
        let formModel = new FormModel(obj);
        formModel.get(groupName);
    });

    it('test handleAction action.formId is null', function () {
        setGlobal();
        let formHandler = {};
        let formModel = new FormModel(obj);
        formModel.handleAction(formHandler);
    });

    it('test handleAction error in formHandler', function () {
        setGlobal();
        let formHandler = {
            'error': {
                apply: function () {
                }
            }
        };
        let formModel = new FormModel(obj);
        formModel.handleAction(formHandler);
    });

    it('test handleAction Form handler undefined', function () {
        setGlobal2();
        let formHandler = {};
        let formModel = new FormModel(obj);

        expect(function () {
            formModel.handleAction(formHandler);
        })
            .to
            .throw(Error);
    });

    it('test handleAction normal', function () {
        setGlobal2();
        let formHandler = {
            '100': {
                apply: function () {

                }
            }
        };
        let formModel = new FormModel(obj);
        formModel.handleAction(formHandler);
    });

    it('test copyFrom normal', function () {
        setGlobal();
        let updateObject = {};
        let formModel = new FormModel({
            clear: function () {

            },
            copyFrom: function () {

            }
        });
        formModel.copyFrom(updateObject, true);
    });

    it('test copyTo normal', function () {
        setGlobal2();
        let updateObject = {};
        let formModel = new FormModel({
            clear: function () {

            },
            copyTo: function () {

            }
        });
        formModel.copyTo(updateObject, true);
    });

    it('test clear normal', function () {
        let formModel = new FormModel({
            clearFormElement: function () {

            }
        });
        formModel.clear();
    });

    it('test invalidate normal not param', function () {
        let formModel = new FormModel({
            invalidateFormElement: function () {

            }
        });
        formModel.invalidate();
    });

    it('test invalidate normal has param', function () {
        let formModel = new FormModel({
            invalidateFormElement: function () {

            }
        });
        formModel.invalidate('error');
    });

    it('test value normal', function () {
        let formModel = new FormModel({
            value: ''
        });
        formModel.value();
    });

    it('test getValue normal', function () {
        let groupName = '';
        let formModel = new FormModel({
            value: ''
        });
        formModel.getValue(groupName);
    });

    it('test setValue normal', function () {
        let groupName = '';
        let formModel = new FormModel({
            value: ''
        });
        formModel.setValue(groupName, 'value');
    });

    it('test getBinding normal', function () {
        let formModel = new FormModel(obj);
        formModel.getBinding();
    });

});

