﻿'use strict';

var assert = require('chai').assert;

var CustomerModel = require('../../../../mocks/scripts/models/CustomerModel');

var obj = {
    name: 'test code'
};

describe('CustomerModel Unit Test', function () {
    it('test 1', function () {
        let customerModel = new CustomerModel(obj);
    });
});

