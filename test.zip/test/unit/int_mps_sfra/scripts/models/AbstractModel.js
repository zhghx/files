'use strict';

var { assert, expect } = require('chai');

var AbstractModel = require('../../../../mocks/scripts/models/AbstractModel');

var obj = {
    custom: {},
    name: 'test code'
};

function setGlobal() {
    global.empty = function (obj) {
        if (!obj) {
            return true;
        }
        return false;
    };
}

describe('AbstractModel Unit Test', function () {
    it('test obj is null', function () {
        expect(function () {
            new AbstractModel(null);
        })
            .to
            .throw(Error);
    });

    it('test get ', function () {
        let abstractModel = new AbstractModel(obj);
        abstractModel.get();
    });

    it('test setValue, getValue normal ', function () {
        setGlobal();
        let abstractModel = new AbstractModel(obj);
        abstractModel.setValue('key1', 'value1');
        abstractModel.getValue('key1');
    });

    it('test setValue, getValue null ', function () {
        setGlobal();
        let abstractModel = new AbstractModel(obj);
        abstractModel.setValue(null, null);
        abstractModel.getValue(null);
    });

    it('test setValue, getValue exception ', function () {
        setGlobal();
        let abstractModel = new AbstractModel({});
        abstractModel.setValue('key1', 'value1');
        expect(function () {
            abstractModel.getValue('key1');
        })
            .to
            .throw(Error);
    });

    it('test initProperties normal ', function () {
        setGlobal();
        let abstractModel = new AbstractModel(obj);
        abstractModel.initProperties();
    });

    it('test initProperties property get is has', function () {
        obj.getName = {
            test: 'test'
        };
        obj.setName = {
            test: 'test'
        };
        let abstractModel = new AbstractModel(obj);
        abstractModel.initProperties();
    });

    it('test __noSuchMethod__ call is fun in object', function () {
        obj.testMethod = function (testArgs) {
            console.log(testArgs);
        };
        let abstractModel = new AbstractModel(obj);
        expect(function () {
            abstractModel.__noSuchMethod__('testMethod', 'testArgs');
        })
            .to
            .throw(Error);
    });

    it('test __noSuchMethod__ call is fun in not object', function () {
        let abstractModel = new AbstractModel(obj);
        expect(function () {
            abstractModel.__noSuchMethod__('testMethod2', 'testArgs2');
        })
            .to
            .throw(Error);
    });
});

