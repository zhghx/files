'use strict';

var assert = require('chai').assert;

var AddressModel = require('../../../../mocks/scripts/models/AddressModel');

var obj = {
    custom: {},
    name: 'test code'
};

function setGlobal() {
    global.empty = function (obj) {
        if (!obj) {
            return true;
        }
        return false;
    };
    global.customer = {
        profile: {
            addressBook: {
                createAddress: function (param) {
                    return param;
                }
            }
        }
    };
}

describe('AddressModel Unit Test', function () {
    it('test create', function () {
        setGlobal();
        let addressForm = {
            states: {},
            addressId: {
                htmlValue: 1
            }
        };
        AddressModel.create(addressForm);
    });

    it('test create address is null', function () {
        setGlobal();
        let addressForm = {
            states: {},
            addressId: {}
        };
        AddressModel.create(addressForm);
    });

    it('test create addressForm states is null', function () {
        setGlobal();
        let addressForm = {
            states: null,
            addressId: {
                htmlValue: 1
            }
        };
        AddressModel.create(addressForm);
    });
});