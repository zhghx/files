'use strict';

var { assert, expect } = require('chai');

var AddressModel = require('../../../../mocks/scripts/models/AddressModel');

function setGlobal() {
    global.empty = function (obj) {
        if (!obj) {
            return true;
        }
        return false;
    };
    global.customer = {
        profile: {
            addressBook: {
                addresses: [
                    {
                        ID: '1',
                        name: 'address1',
                        states: {},
                        addressId: {
                            htmlValue: '1',
                            invalidateFormElement: function () {
                            }
                        }
                    },
                    {
                        ID: '2',
                        name: 'address2',
                        states: {},
                        addressId: {
                            htmlValue: '1',
                            invalidateFormElement: function () {
                            }
                        }
                    },
                    {
                        ID: 'default',
                        name: 'defaultAddress'
                    }
                ],
                createAddress: function (param) {
                    return param;
                },
                getAddress: function (param) {
                    for (let i = 0; i < customer.profile.addressBook.addresses.length; i++) {
                        let address = customer.profile.addressBook.addresses[i];
                        if (address.ID === param) {
                            return address;
                        }
                    }
                    return null;
                },
                getPreferredAddress() {
                    return customer.profile.addressBook.getAddress('default');
                }
            }
        }
    };
}

describe('AddressModel Unit Test', function () {
    it('test create', function () {
        setGlobal();
        let addressForm = {
            states: {},
            addressId: {
                htmlValue: '1',
                invalidateFormElement: function () {
                }
            },
            addressName: {
                htmlValue: 'address1'
            }
        };
        AddressModel.create(addressForm);
    });

    it('test create address is null', function () {
        setGlobal();
        let addressForm = {
            states: {},
            addressId: {
                htmlValue: null,
                invalidateFormElement: function () {
                }
            },
            addressName: {
                htmlValue: 'address1'
            }
        };
        AddressModel.create(addressForm);
    });

    it('test create addressForm states is null', function () {
        setGlobal();
        let addressForm = {
            states: null,
            addressId: {
                htmlValue: '1',
                invalidateFormElement: function () {
                }
            },
            addressName: {
                htmlValue: 'address1'
            }
        };
        AddressModel.create(addressForm);
    });

    it('test update Address name already exists use default address', function () {
        setGlobal();
        let addressForm = {
            addressId: {
                htmlValue: '1',
                invalidateFormElement: function () {
                }
            },
            addressName: {
                htmlValue: 'address1'
            }
        };
        expect(function () {
            AddressModel.update('2', addressForm);
        })
            .to
            .throw(Error);
    });

    it('test update No address found', function () {
        setGlobal();
        let addressForm = {
            addressId: {
                htmlValue: '1',
                invalidateFormElement: function () {
                }
            },
            addressName: {
                htmlValue: 'address1'
            }
        };
        expect(function () {
            AddressModel.update('999', addressForm);
        })
            .to
            .throw(Error);
    });

    it('test update Address name already exists', function () {
        setGlobal();
        let addressForm = {
            addressId: {
                htmlValue: '1',
                invalidateFormElement: function () {
                }
            }
        };
        expect(function () {
            AddressModel.update('default', addressForm);
        })
            .to
            .throw(Error);
    });

    it('test update normal', function () {
        setGlobal();
        let addressForm = {
            addressId: {
                htmlValue: '1',
                invalidateFormElement: function () {
                }
            }
        };
        AddressModel.update('1', addressForm);
    });
});