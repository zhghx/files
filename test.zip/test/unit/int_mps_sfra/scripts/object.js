'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();

var { assert, expect } = require('chai');

function HashMap() {
    return {
        element: [],
        entrySet: function () {
            return this.element;
        },
        put: function () {
        }
    };
}

var object = proxyquire('../../../../cartridges/int_mps_sfra/cartridge/scripts/object', {
    'dw/util/HashMap': HashMap
});

describe('object Unit Test', function () {
    it('test extend', function () {
        let target = {
            a: 1
        };
        let source = {
            c: 3
        };
        object.extend(target, source);
    });

    it('test extend object', function () {
        let target = {
            a: 1
        };
        let source = {
            c: 3,
            obj: {
                b: 2
            }
        };
        object.extend(target, source);
    });

    it('test extend null', function () {
        object.extend(null, null);
    });

    it('test resolve undefined', function () {
        object.resolve({}, 'str1');
    });

    it('test resolve', function () {
        let obj = {
            'str1': 'a',
            'str2': 'b',
            'str3': 'c'
        };
        let resolve = object.resolve(obj, 'str1');
        assert.equal(resolve, 'a');
    });

    it('test values', function () {
        let obj = {
            'str1': 'a',
            'str2': 'b',
            'str3': 'c'
        };
        let values = object.values(obj);
        assert.equal('["a","b","c"]', JSON.stringify(values));
    });

    it('test keys', function () {
        object.keys({}, {});
    });

    it('test toHashMap', function () {
        let obj = {
            'str1': 'a',
            'str2': 'b',
            'str3': 'c'
        };
        object.toHashMap(obj);
    });

    it('test fromHashMap', function () {
        new HashMap;
        object.fromHashMap(new HashMap);
    });
});

