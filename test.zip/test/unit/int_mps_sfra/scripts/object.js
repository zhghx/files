'use strict';

var proxyquire = require('proxyquire')
    .noCallThru()
    .noPreserveCache();

function HashMap() {
    return {
        element: [],
        entrySet: function () {
            return this.element;
        },
        put: function () {
        }
    };
}

var object = proxyquire('../../../../cartridges/int_mps_sfra/cartridge/scripts/object', {
    'dw/util/HashMap': HashMap
});

describe('object Unit Test', function () {
    it('test extend', function () {
        object.extend({}, {});
    });

    it('test resolve', function () {
        object.resolve({}, 'str1, str2');
    });

    it('test values', function () {
        object.values({}, {});
    });

    it('test keys', function () {
        object.keys({}, {});
    });

    it('test toHashMap', function () {
        object.toHashMap({}, {});
    });

    it('test fromHashMap', function () {

        new HashMap;
        object.fromHashMap(new HashMap);
    });
});

