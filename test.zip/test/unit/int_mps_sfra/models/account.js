'use strict';

var assert = require('chai').assert;

var ArrayList = require('../../../mocks/dw.util.Collection');

var currentCustomer = {
    addressBook: {
        addresses: {},
        preferredAddress: {
            address1: '15 South Point Drive',
            address2: null,
            city: 'Boston',
            countryCode: {
                displayValue: 'United States',
                value: 'US'
            },
            firstName: 'John',
            lastName: 'Snow',
            ID: 'Home',
            postalCode: '02125',
            stateCode: 'MA'
        }
    },
    customer: {},
    profile: {
        firstName: 'John',
        lastName: 'Snow',
        email: 'jsnow@starks.com',
        phone: '18210459887',
        password: '********'
    },
    wallet: {
        paymentInstruments: [
            {
                creditCardHolder: '22',
                creditCardExpirationMonth: '12',
                creditCardExpirationYear: '2020',
                maskedCreditCardNumber: '***********1111',
                creditCardType: 'visa',
                UUID: '1'
            }
        ]
    },
    raw: {
        authenticated: true,
        registered: true,
        externallyAuthenticated: true
    }
};

var addressModel = {
    address: {
        address1: '15 South Point Drive',
        address2: null,
        city: 'Boston',
        countryCode: {
            displayValue: 'United States',
            value: 'US'
        },
        firstName: 'John',
        lastName: 'Snow',
        ID: 'Home',
        postalCode: '02125',
        stateCode: 'MA'
    }
};

var orderModel = {
    orderNumber: '00000204',
    orderStatus: {
        displayValue: 'NEW'
    },
    creationDate: 'some Date',
    shippedToFirstName: 'John',
    shippedToLastName: 'Snow',
    shipping: {
        shippingAddress: {
            address1: '15 South Point Drive',
            address2: null,
            city: 'Boston',
            countryCode: {
                displayValue: 'United States',
                value: 'US'
            },
            firstName: 'John',
            lastName: 'Snow',
            ID: 'Home',
            phone: '123-123-1234',
            postalCode: '02125',
            stateCode: 'MA'
        }
    },
    items: new ArrayList([
        {
            product: {
                getImage: function () {
                    return {
                        URL: {
                            relative: function () {
                                return 'Some String';
                            }
                        }
                    };
                }
            }
        }
    ]),
    priceTotal: 125.99,
    totals: {
        grandTotal: 125.99
    },
    productQuantityTotal: 3
};

describe('account', function () {
    var AccountModel = require('../../../mocks/models/account');

    describe('account', function () {
        it('payment customerPaymentInstruments value equal', function () {
            var result = new AccountModel(currentCustomer, addressModel, orderModel);
            assert.equal(result.payment.maskedCreditCardNumber, '***********1111');
            assert.equal(result.payment.creditCardType, 'visa');
            assert.equal(result.payment.creditCardExpirationMonth, '12');
            assert.equal(result.payment.creditCardExpirationYear, '2020');

            assert.equal(result.customerPaymentInstruments[0].creditCardHolder, '22');
            assert.equal(result.customerPaymentInstruments[0].maskedCreditCardNumber, '***********1111');
            assert.equal(result.customerPaymentInstruments[0].creditCardType, 'visa');
            assert.equal(result.customerPaymentInstruments[0].creditCardExpirationMonth, '12');
            assert.equal(result.customerPaymentInstruments[0].creditCardExpirationYear, '2020');
            assert.equal(result.customerPaymentInstruments[0].UUID, '1');
        });
    });
});
