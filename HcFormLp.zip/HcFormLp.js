'use strict';

/**
 * フォーム一体型LP用コントローラー
 * @module controllers/HcUtil
 */

var params = request.httpParameterMap;

/* Script Modules */
var app = require('*/cartridge/scripts/app');
var guard = require('*/cartridge/scripts/guard');
var ISML = require('dw/template/ISML');
var Resource = require('dw/web/Resource');
var Transaction = require('dw/system/Transaction');
var URLUtils = require('dw/web/URLUtils');
var OneTimePwdMgr = require('*/cartridge/scripts/util/OneTimePwdMgr');
var PaymentMgr = require('dw/order/PaymentMgr');
var Countries = require('*/cartridge/scripts/util/Countries');
var PaymentInstrument = require('dw/order/PaymentInstrument');
var CustomerMgr = require('dw/customer/CustomerMgr');
var hcLogger = require('*/cartridge/scripts/util/HcLogger');


/**********************************************************************************
 * フォーム一体型LPページを表示する
 * @todo 媒体番号の注文への引継ぎ
 * @todo 割引部分の表示
 */
function show() {
	//app.getForm('formlp.selectedproductid').clear();
	//if (empty(session.custom.txOneTimePwd)) {
	//	app.getForm('formlp').clear();
	//}

	//リクエストパラメータを取得
    var param = request.httpParameterMap;
    dw.system.Logger.info("formlp.selectedproductid : " + app.getForm('formlp.selectedproductid').object.getHtmlValue());
    //表示する商品情報を取得

    //商品IDリスト
    var productIds = 'pids' in param ? param.pids : null;
    //コンテンツアセットIDを取得
    var cid = 'cid' in param ? param.cid : null;
    //媒体番号入力欄を表示する/しない
	var optDispMediaNo = 'optDispMediaNo' in param ? param.optDispMediaNo : false;
	//お届け希望日時指定する/しない
	var optDispShipDay = 'optDispShipDay' in param && param.optDispShipDay !='' ? param.optDispShipDay : false;
	//お届け希望時間指定する/しない
	var optDispShipTime = 'optDispShipTime' in param && param.optDispShipTime !='' ? param.optDispShipTime : false;
	//支払い方法指定(フロントページ)
	var optDispPaymentMethod = 'optDispPaymentMethod' in param && param.optDispPaymentMethod !='' ? param.optDispPaymentMethod : 'VERITRANS_CREDIT_CARD COD NP_PAYMENT';
	dw.system.Logger.info("optDispPaymentMethod : " + optDispPaymentMethod);
	//支払い方法指定(アップセル)
	var optDispPaymentMethodUpsell = 'optDispPaymentMethodUpsell' in param && param.optDispPaymentMethodUpsell !='' ? param.optDispPaymentMethodUpsell : 'VERITRANS_CREDIT_CARD COD NP_PAYMENT';
	dw.system.Logger.info("optDispPaymentMethodUpsell : " + optDispPaymentMethodUpsell);
	//確認画面コンテンツID
	var confirmCid = 'confirmCid' in param ? param.confirmCid : null;
	//アップセル用商品ID
	var upsellPids = 'upsellPids' in param ? param.upsellPids : null;
	//表示フラグ(0：商品リストをそのまま表示、1：選択中の商品のみ表示)
	var dispMode = 'dispMode' in param ? param.dispMode : '0';
	//割引価格
	var adjustedPrices = 'adjustedPrices' in param ? param.adjustedPrices : null;

	//#9707 ワンタイムパスワード有効フラグ Start.
	var enabledOtp = ('enabledOtp' in param && param.enabledOtp != '') ? param.enabledOtp : false;
	//#9707 ワンタイムパスワード有効フラグ End.

    //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
    //確認画面遷移エラー、アップセル精査エラーでカートに追加されてしまっている商品をここで消す
    //タグ連携に関しても確認画面遷移、アップセルの処理時にカートから商品を消してしまっているのでこの時点でカート削除のタグを出力できるようにする
    var removeProductLineItems = [];
    var cart = app.getModel('Cart').goc();
    if ('txRemoveProductTag' in session.custom && session.custom.txRemoveProductTag !== null) {
        cart.clearCart(null);
        cart.clearNotes();

        //削除対象の商品がなければカートを消しただけで終了
        if (session.custom.txRemoveProductTag !== '') {
            var removeTagProducts = session.custom.txRemoveProductTag.split(';');
            var ProductMgr = require('dw/catalog/ProductMgr');

            for (var i = 0; i < removeTagProducts.length; i++){
                var removeTagProduct = removeTagProducts[i];
                var removeTagProductData = removeTagProduct.split(',');
                var product = ProductMgr.getProduct(removeTagProductData[0]);
                var quantityValue = removeTagProductData[1];

                removeProductLineItems.push({
                    product: product,
                    quantityValue: quantityValue
                });
            }
        }
        delete session.custom.txRemoveProductTag;
    }
    //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.

	if (productIds) {
    	//数量パラメータの解析
    	//スペースで分割
    	var prodList = parseProductList(productIds.stringValue,adjustedPrices);

    	//クレジットカート情報を取得
        var creditCardList = initCreditCardList(optDispPaymentMethod);
        var applicablePaymentMethods = creditCardList.ApplicablePaymentMethods;

        var billingForm = app.getForm('billing').object;
        var paymentMethods = billingForm.paymentMethods;
        if (paymentMethods.selectedPaymentMethodID.valid) {
            paymentMethods.selectedPaymentMethodID.setOptions(applicablePaymentMethods.iterator());
        } else {
            paymentMethods.clearFormElement();
        }

        //確認画面で利用するためフォームへ登録
        if(upsellPids){
        	app.getForm('formlp.upsellpids').object.setHtmlValue(upsellPids);
        }
        if(confirmCid){
        	app.getForm('formlp.confirmcid').object.setHtmlValue(confirmCid);
        }
        if(adjustedPrices){
        	app.getForm('formlp.adjustedprices').object.setHtmlValue(adjustedPrices);
        }

        app.getForm('formlp.optdispshipday').object.setValue(optDispShipDay);
        app.getForm('formlp.optdispshiptime').object.setValue(optDispShipTime);
        app.getForm('formlp.optdisppaymentmethodupsell').object.setValue(optDispPaymentMethodUpsell);

        //選択商品の初期値設定
        if (empty(app.getForm('formlp.selectedproductid').object.getHtmlValue())) {
        	//prodListに1つしか商品がない場合その商品を設定
        	if (prodList.length == 1){
        		app.getForm('formlp.selectedproductid').object.setHtmlValue(prodList.get(0).product.ID);
        		//選択商品数の初期値設定
        		app.getForm('formlp.selectedproductqty').object.setHtmlValue(prodList.get(0).qty1);
        	} else {
        		//空のまま
        	}
        } else if(productIds.stringValue.indexOf(app.getForm('formlp.selectedproductid').object.getHtmlValue()) < 0){
        	//アップセル選択後に1ページ目を再表示する場合、アップセル前に選択した商品を再設定
			app.getForm('formlp.selectedproductid').object.setHtmlValue(session.custom.txPreUpsellPid);
        	app.getForm('formlp.selectedproductqty').object.setHtmlValue(session.custom.txPreUpsellQty);
        }


//        if (empty(app.getForm('formlp.delivedate').object.getHtmlValue())) {
//            var today = new dw.util.Calendar();
//            today.setTimeZone('Asia/Tokyo');
//            var todayStr = dw.util.StringUtils.formatCalendar(today,'yyyy/MM/dd');
//        	app.getForm('formlp.delivedate').object.setHtmlValue(todayStr);
//        }
        //お届け希望日用カレンダーの有効範囲
        var maxDate = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryMaxDate');
        var minDate = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryMinDate');
        for(let i = 0; i < prodList.length; i++){
            if(prodList[i].product != null && !empty(prodList[i].product)){
                prodList[i].minDate = minDate;
                prodList[i].maxDate = maxDate;
                var availability = prodList[i].product.getAvailabilityModel();
                if(availability != null && !empty(availability)){
                    var inventoryRecord = availability.getInventoryRecord();
                    if(inventoryRecord && inventoryRecord.preorderable){
                        var inStockDate = inventoryRecord.inStockDate;
                        if(inStockDate != null && !empty(inStockDate)){
                            var inStockCal = new dw.util.Calendar();
                            inStockCal.setTimeZone('Asia/Tokyo');
                            inStockCal.setTime(inStockDate);
                            inStockDate = dw.util.StringUtils.formatCalendar(inStockCal,'yyyy/MM/dd');
                            inStockDate = new Date(inStockDate);
                            var dateRange = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryDateRange');
                            var today =  new dw.util.Calendar();
                            today .setTimeZone('Asia/Tokyo');
                            today = dw.util.StringUtils.formatCalendar(today,'yyyy/MM/dd');
                            today = new Date(today);
                            var min = (inStockDate - today)/86400000;
                            if(minDate < min){
                                prodList[i].minDate = min;
                            }
                            prodList[i].maxDate = prodList[i].minDate + dateRange;
                        }
                    }
                }
            }
        }

        //View表示
    	app.getView({
    		products: prodList,
    		cid: cid,
    		optDispMediaNo: optDispMediaNo.booleanValue,
    		optDispShipDay: optDispShipDay.booleanValue,
    		optDispShipTime: optDispShipTime.booleanValue,
    		confirmCid: confirmCid,
    		upsellPids: upsellPids,
    		dispMode: dispMode,
    		enabledOtp: enabledOtp,
    		adjustedPrices: adjustedPrices,
            //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
            ContinueURL: URLUtils.https('HcFormLp-FormLpForm'),
            removeProductLineItems: removeProductLineItems,
            Basket: cart.object
            //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.
        }).render('product/formlp');
    }
    return;
}

/**********************************************************************************
 * 各種アクション
 * @returns
 * @todo ワンタイムパスワードメールの見直し
 * @todo エラーメッセージ表示（共通エラー）
 * @todo セット品のカート投入
 * @todo 投入NG時の所作
 * @todo オプション設定のカート投入
 * @todo 支払方法の制限
 * @todo 配送方法の自動決定
 *
 */
function formLpForm() {
    app.getForm('formlp').handleAction({

    	//ワンタイムパスワード発行アクション
    	issueonetimepwd: function () {
    		var isProfileUpdateValid = true;
            if (app.getForm('formlp.profile.customer.email').value() !== app.getForm('formlp.profile.customer.emailconfirm').value()) {
                app.getForm('formlp.profile.customer.emailconfirm').invalidate();
                isProfileUpdateValid = false;
            } else {
            	var TempCustomer =
                	CustomerMgr.getCustomerByLogin(app.getForm('formlp.profile.customer.email').value()) ||
                		CustomerMgr.searchProfiles('custom.txEmail2 = {0}','custom.txEmail2 asc',app.getForm('formlp.profile.customer.email').value()).first();
            	//アカウント存在チェック
                if (TempCustomer) {
                	//app.getForm('formlp').invalidateFormElement();
                    app.getForm('formlp.profile.customer.email').invalidate();
                }

            	if (!OneTimePwdMgr.issue(app.getForm('formlp.profile.customer.email').value())) {
            		//エラーの場合（登録済チェックはこの中には実装されていない。なんらか想定外の原因でエラーが起きた場合）
                    app.getForm('formlp').invalidateFormElement();
                    app.getForm('formlp.profile.customer.email').invalidate();
            	}
            }
            response.redirect(app.getForm('formlp.errredirect').value());
        },

        //認証処理アクション
        authonetimepwd: function() {
        	if (!OneTimePwdMgr.auth(app.getForm('formlp.pwd').value())) {
                app.getForm('formlp.pwd').invalidate();
        	}
            response.redirect(app.getForm('formlp.errredirect').value());
        },

        //入力確認アクション（確認画面表示）
        confirmation: function() {
        	//カートに商品を投入する
            var cart = app.getModel('Cart').goc();
            //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
            var removeProductLineItems = [];
            for (var it = cart.object.getAllProductLineItems().iterator(); it.hasNext();){
                var target = it.next();
                if(target.product != null){
                    removeProductLineItems.push({
                        product: target.product,
                        quantityValue: target.quantityValue
                    });
                }
            }
            //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.
            cart.clearCart(null);
            var pid = app.getForm('formlp.selectedproductid').value();
            var qty = app.getForm('formlp.selectedproductqty').value();
            //アップセル後でない確認画面表示の場合、アップセル選択後に1ページ目を表示する場合向けの初期選択値を保持しておく
            if(!app.getForm('formlp.ischangeupsellproduct').value()){
            	session.custom.txPreUpsellPid = pid;
            	session.custom.txPreUpsellQty = qty;
            }
            cart.addProductToCart();

            var upsellpids = app.getForm('formlp.upsellpids').value();
            var adjustedPrices = app.getForm('formlp.adjustedprices').value();
            if(upsellpids && upsellpids !== undefined){
            	var prodList = parseUpsellProductList(upsellpids,adjustedPrices);
            }


    		if(typeof adjustedPrices !== 'undefined' && adjustedPrices !== null){
    			var priceArr = parseAdjustedPriceList(adjustedPrices,pid,qty,cart);
    		}

            //精査及び確認画面で利用するためフォームへ登録
            //app.getForm('formlp.checkdelivedate').object.setHtmlValue(params.isDeliveDate);
            //app.getForm('formlp.checkdelivetime').object.setHtmlValue(params.isDeliveTime);

            var isValid = true;
            var msList='';
            var includeSubsc = false;

            //カートに配送情報を設定する
        	handleShippingSettings(cart);

        	//日時指定不可商品がカートにある場合
        	for (var it = cart.object.getAllProductLineItems().iterator(); it.hasNext();){
        		var productInCart = it.next();
        		if(productInCart.product != null){
        			if(productInCart.product.custom.txHideDelivedateSelect && (session.forms.formlp.checkdelivedate.value == '1' || session.forms.formlp.checkdelivetime.value == '1')){
        				msList += ',' + Resource.msg('hcformlp.formlp.delivedateselecterror', 'hcformlp', null);
            			isValid = false;
        			}

        			//定期商品があるかどうかを記録しておく
        			if(!includeSubsc && !productInCart.bonusProductLineItem && productInCart.product.custom.txShippingProductType.value == '2'){
        				includeSubsc = true;
        			}

        		}
        	}
        	//お届け希望日用カレンダーの有効範囲
            var maxDate = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryMaxDate');
            var minDate = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryMinDate');
            for(let i = 0; i < prodList.length; i++){
                if(prodList[i].product != null && !empty(prodList[i].product)){
                    prodList[i].minDate = minDate;
                    prodList[i].maxDate = maxDate;
                    var availability = prodList[i].product.getAvailabilityModel();
                    if(availability != null && !empty(availability)){
                        var inventoryRecord = availability.getInventoryRecord();
                        if(inventoryRecord && inventoryRecord.preorderable){
                            var inStockDate = inventoryRecord.inStockDate;
                            if(inStockDate != null && !empty(inStockDate)){
                                var inStockCal = new dw.util.Calendar();
                                inStockCal.setTimeZone('Asia/Tokyo');
                                inStockCal.setTime(inStockDate);
                                inStockDate = dw.util.StringUtils.formatCalendar(inStockCal,'yyyy/MM/dd');
                                inStockDate = new Date(inStockDate);
                                var dateRange = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryDateRange');
                                var today =  new dw.util.Calendar();
                                today .setTimeZone('Asia/Tokyo');
                                today = dw.util.StringUtils.formatCalendar(today,'yyyy/MM/dd');
                                today = new Date(today);
                                var min = (inStockDate - today)/86400000;
                                if(minDate < min){
                                    prodList[i].minDate = min;
                                }
                                prodList[i].maxDate = prodList[i].minDate + dateRange;
                            }
                        }
                    }
                    if(session.forms.formlp.checkdelivedate.value == '1'){
                        let selectDelivedate = session.forms.formlp.delivedate.value;
                        let selectDeliveCal =  new dw.util.Calendar();
                        selectDeliveCal .setTimeZone('Asia/Tokyo');
                        selectDeliveCal.setTime(selectDelivedate);
                        if(app.getController('COShipping').DeliveCalendarScope(selectDeliveCal,prodList[i].maxDate,prodList[i].minDate)){
                            prodList[i].deliveScope = 1;
                        }else{
                            prodList[i].deliveScope = 0;
                        }
                    }else{
                        prodList[i].deliveScope = 0;
                    }
                }
            }

        	//ネコポスor郵便の場合に配送希望を選択していたらエラーを返す
        	for (var it = cart.object.getShipments().iterator(); it.hasNext();){
        		var cartshipment = it.next();
        		if((cartshipment.getShippingMethod().ID.indexOf("txDelivery") != 0) && (session.forms.formlp.checkdelivedate.value == '1' || session.forms.formlp.checkdelivetime.value == '1')){
        			//ネコポスで日付指定されていても、定期商品の場合はエラーとしない
        			if(!includeSubsc){
	        			msList += ',' + Resource.msg('hcformlp.formlp.delivedateselecterror.notdelivery', 'hcformlp', null);
	        			isValid = false;
        			}
        		}
        	}

            //【FFHC v1.0】2.3.4. 支払方法　Start.(Cart.js show()から移植＋改修)
            //顧客、国コード、合計金額で利用可能な支払方法が無い場合はエラーメッセージ表示
            var countryCode = Countries.getCurrent({
                CurrentRequest: {
                    locale: request.locale
                }
            }).countryCode;

            if((priceArr != null && priceArr[1] ==0 ) || cart.object.totalGrossPrice.value == 0){
            	//注文総額が0円の場合、フォームの支払い方法を上書きする（フロントページでは商品選択があり注文情報確定しておらず支払い方法非表示制御ができないため）
            	app.getForm('billing').object.paymentMethods.selectedPaymentMethodID.setValue(PaymentInstrument.METHOD_GIFT_CERTIFICATE);
            }else{
            	var selectedPaymentMethodID = app.getForm('billing').object.paymentMethods.selectedPaymentMethodID;

            	if(dw.order.PaymentMgr.getApplicablePaymentMethods(customer,countryCode,cart.object.adjustedMerchandizeTotalPrice.value).size() == 0){
            		msList += ',' + Resource.msg('hcformlp.formlp.paymentmethoderror', 'hcformlp', null);
            		isValid = false;
            	}else{

            		//ネコポスor郵便の場合に支払方法CODを選択していたらエラーを返す
            		for (var it = cart.object.getShipments().iterator(); it.hasNext();){
            			var cartshipment = it.next();
            			if((cartshipment.getShippingMethod().ID.indexOf("txDelivery") != 0) && selectedPaymentMethodID.value.equals('COD')){
            				msList += ',' + Resource.msg('hcformlp.formlp.paymentmethoderror.cod', 'hcformlp', null);
            				isValid = false;
            			}
            		}
            		if(isValid){
            			var methods = dw.order.PaymentMgr.getApplicablePaymentMethods(customer,countryCode,cart.object.adjustedMerchandizeTotalPrice.value);

            			var methodIDs = new Array();
            			for (var i = 0; i < methods.length; i++) {
            				methodIDs.push(methods[i].getID().toString());
            				dw.system.Logger.info("methods[i].getID().toString() : " + methods[i].getID().toString());
            				if(methods[i].getID().toString()===selectedPaymentMethodID.value){dw.system.Logger.info("等しい : " + methods[i].getID().toString());}

            			}
            			dw.system.Logger.info("methodIDs.length : " + methodIDs.length);
            			if(methodIDs.indexOf(selectedPaymentMethodID.value) == -1){
            				dw.system.Logger.info("typeof : " + typeof(selectedPaymentMethodID.value));

            				msList += ',' + Resource.msg('hcformlp.formlp.paymentmethoderror2', 'hcformlp', null);
            				isValid = false;
            			}
            		}
            	}
            }

            // Mark step as fulfilled.
            session.forms.singleshipping.fulfilled.value = true;

            var COBilling = app.getController('COBilling');


            //@todo
            //COBilling.resetPaymentForms
            COBilling.resetPaymentForms;
            dw.system.Logger.info("selectedPaymentMethodID : " + app.getForm('billing').object.paymentMethods.selectedPaymentMethodID.value);


        	//カートに支払方法を設定する
            if (COBilling.HandlePaymentSelection(cart).error) {
            	//error
            	msList += ',' + Resource.msg('hcformlp.formlp.paymenterror', 'hcformlp', null);
            	isValid = false;
            } else {
			// Mark step as fulfilled
                app.getForm('billing').object.fulfilled.value = true;
            }

        	//アップセル用支払い方法を取得
            var optDispPaymentMethodUpsell = app.getForm('formlp.optdisppaymentmethodupsell').value();
            var creditCardListUpsell = initCreditCardList(optDispPaymentMethodUpsell);
            var applicablePaymentMethodsUpsell = creditCardListUpsell.ApplicablePaymentMethods;
            dw.system.Logger.info("applicablePaymentMethodsUpsell : " + applicablePaymentMethodsUpsell);

            var billingFormUpsell = app.getForm('billing').object;
            var paymentMethodsUpsell = billingFormUpsell.paymentMethods;
            if (paymentMethodsUpsell.selectedPaymentMethodID.valid) {
                paymentMethodsUpsell.selectedPaymentMethodID.setOptions(applicablePaymentMethodsUpsell.iterator());
            } else {
            	dw.system.Logger.info("paymentMethodsUpsell.invalid");
                paymentMethodsUpsell.clearFormElement();
            }



//        	//クレジットカート情報を取得
//            var creditCardList = initCreditCardList(optDispPaymentMethod);
//            var applicablePaymentMethods = creditCardList.ApplicablePaymentMethods;
//
//            var billingForm = app.getForm('billing').object;
//            var paymentMethods = billingForm.paymentMethods;
//            if (paymentMethods.valid) {
//                paymentMethods.selectedPaymentMethodID.setOptions(applicablePaymentMethods.iterator());
//            } else {
//                paymentMethods.clearFormElement();
//            }


            //会員登録入力内容チェック
            //session.custom.txOrderFromFormLp = true;
            //var Account = app.getController('Account');
        	//Account.RegistrationForm();

            var email, emailConfirmation, orderNo, password, passwordConfirmation, existingCustomer, Customer;
            // 【FFHC v1.0】 2.1.1. 新規会員登録　Start.
            //var msList = new Array();

            var fullName = app.getForm('formlp.profile.customer.firstname').value()
                          + app.getForm('formlp.profile.customer.lastname').value();
            var today = new dw.util.Calendar();
            var year = app.getForm('formlp.profile.customer.bml.year').value();
            var month = app.getForm('formlp.profile.customer.bml.month').value()-1;
            var day = app.getForm('formlp.profile.customer.bml.day').value();

            var date = new Date(year, month, day);
            //入力日付の有効日付チェック
            if (year !== date.getFullYear() || month !== date.getMonth() || day !== date.getDate()) {
                msList += ',' + Resource.msg('validate.date', 'forms', null);
                isValid = false;
                dw.system.Logger.info("入力日付エラー");
            }
            var birthdate = new dw.util.Calendar(date);
            var birthdateConfirmation = new dw.util.Calendar(date);
            birthdateConfirmation.setTimeZone('Asia/Tokyo');
            today.setTimeZone('Asia/Tokyo');

         // 【FFHC v1.0】 2.1.1. 新規会員登録　End.

            Customer = app.getModel('Customer');
            email = app.getForm('formlp.profile.customer.email').value();
            emailConfirmation = app.getForm('formlp.profile.customer.emailconfirm').value();
            orderNo =  app.getForm('formlp.profile.customer.orderNo').value();

            // 【FFHC v1.0】 2.1.1. 新規会員登録　Start.
            //姓名の合計が15文字以下チェック
            if(15 < fullName.length){
                msList += ',' + Resource.msg('account.user.registration.fullNameOver', 'account', null);
                isValid = false;
                dw.system.Logger.info("姓名エラー");
            }

            today.clear(today.MINUTE);
            today.clear(today.SECOND);
            today.clear(today.MILLISECOND);
            birthdateConfirmation.clear(birthdateConfirmation.MINUTE);
            birthdateConfirmation.clear(birthdateConfirmation.SECOND);
            birthdateConfirmation.clear(birthdateConfirmation.MILLISECOND);
            //入力日付の未来日チェック
            if(birthdateConfirmation.compareTo(today) > 0){
                msList += ',' + Resource.msg('account.user.registration.birthdate.error', 'account', null);
                isValid = false;
                dw.system.Logger.info("入力日付未来エラー");
            }
            //都道府県以外が入力されていないかチェック
            if(typeof app.getForm('formlp.profile.address.states.state').value() !== 'undefined' ||
             app.getForm('formlp.profile.address.states.state').value() !== null){
                var states = app.getForm('formlp.profile.address.states.state.options');
                var statesLength = Object.keys(states.object).length;
                var state = app.getForm('formlp.profile.address.states.state').value();
                var stateEquals = false;
                for( var i = 0; i < statesLength; i++){
                    if(state.equals(states.object[i].value)){
                        stateEquals = true;
                        break;
                    }
                }
                if(!stateEquals){
                    msList += ',' + Resource.msg('account.user.registration.equalstate', 'account', null);
                    isValid = false;
                    dw.system.Logger.info("都道府県エラー");
                }
             }

            if (email !== emailConfirmation) {
                msList += ',' + Resource.msg('profile.equalTo', 'forms', null);
                isValid = false;
                dw.system.Logger.info("eメールエラー");
            }

            password = app.getForm('formlp.profile.login.password').value();
            dw.system.Logger.info("password lpjs:" +password);
            passwordConfirmation = app.getForm('formlp.profile.login.passwordconfirm').value();

            if (password !== passwordConfirmation) {
                msList += ',' + Resource.msg('profile.passwordnomatch', 'forms', null);
                isValid = false;
                dw.system.Logger.info("パスワードエラー");
            }

            // Checks if login is already taken.
            existingCustomer = Customer.retrieveCustomerByLogin(email);
            if (existingCustomer !== null) {
                msList += ',' + Resource.msg('profile.usernametaken', 'forms', null);
                isValid = false;
                dw.system.Logger.info("顧客存在エラー");
            }

            //会員登録は確定ボタン押した後
            //           if (profileValidation) {
            //               let returnValue;
            //               let phoneReplace = (app.getForm('formlp.profile.customer.phone').value()).replace(/-/g,'');
            //               app.getForm('formlp.profile.customer').setValue('phone', phoneReplace);
            //               app.getForm('formlp.profile.address').setValue('country', 'JP');
            //               app.getForm('formlp.profile.address').setValue('lastname', app.getForm('formlp.profile.customer.lastname').value());
            //               app.getForm('formlp.profile.address').setValue('firstname', app.getForm('formlp.profile.customer.firstname').value());
            //               app.getForm('formlp.profile.customer').setValue('birthday', birthdate.time);
            //
            //               returnValue = Customer.createAccount(email, password, app.getForm('formlp.profile'));
            //               if(!returnValue.error){
            //                   profileValidation = true;
            //                   if (orderNo) {
            //                       var orders = OrderMgr.searchOrders('orderNo={0} AND status!={1}', 'creationDate desc', orderNo,
            //                            dw.order.Order.ORDER_STATUS_REPLACED);
            //                       if (orders) {
            //                           var foundOrder = orders.next();
            //                           Transaction.wrap(function(){
            //                               foundOrder.customer = returnValue.item;
            //                           })
            //                       }
            //                   }
            //               }else{
            //                   profileValidation = false;
            //                   if(typeof returnValue.item === 'undefined' && returnValue.item ===  null){
            //                       app.getView().render('error/generalerror');
            //                       dw.system.Logger.info("なんかしらエラー１");
            //                       return;
            //                   }else{
            //                       msList.push(Resource.msg(returnValue.item, 'account', null));
            //                       dw.system.Logger.info("なんかしらエラー２");
            //                   }
            //
            //               }
                // 【FFHC v1.0】 2.1.1. 新規会員登録　End.
            //           }


            if (!isValid) {
            	session.custom.txErrorList = msList;
                //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
                var txRemoveProductTag = '';
                for (var i = 0; i < removeProductLineItems.length; i++) {
                    var removeTarget = removeProductLineItems[i];
                    if (txRemoveProductTag.length > 0) {
                        txRemoveProductTag = txRemoveProductTag + ';';
                    }
                    txRemoveProductTag = txRemoveProductTag + removeTarget.product.ID + ',' + removeTarget.quantityValue
                }
                session.custom.txRemoveProductTag = txRemoveProductTag;
                //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.
            	response.redirect(app.getForm('formlp.errredirect').value());

            } //確認画面に値を出したいのでここでクリアしない
            //else {
            //  app.getForm('formlp.profile').clear();
            //
            //}

            //【FFHC v1.0】【郵便番号の「-」を抜く】#5998　Start.
            var postalCode = app.getForm('formlp.profile.address').getValue('postal');
            app.getForm('formlp.profile.address').setValue('postal', postalCode.replace('-', ''));
            //【FFHC v1.0】【郵便番号の「-」を抜く】#6511　End.
        	//ここまで会員登録入力精査
        	//

        	dw.system.Logger.info("Account.RegistrationFormcheck is finished");

        	app.getView({
        		ContinueURL: URLUtils.https('HcFormLp-OrderConfirmation'),
        		upsellProducts: prodList,
        		priceArr: priceArr,
        		optDispShipDay: app.getForm('formlp.optdispshipday').object.getValue(),
        		optDispShipTime: app.getForm('formlp.optdispshiptime').object.getValue(),
        		Basket: cart.object,
        		//【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
        		isFormLPSummary: true,
        		removeProductLineItems: removeProductLineItems
        		//【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.
            }).render('product/formlpsummary');

        	//画面構築後、Noteの削除
        	cart.clearNotes();
        },

        //確定アクション（注文完了画面表示）
        submit: function() {

        	//会員情報を生成
        	//CustomerModel...
        	var email, orderNo, isValid, password, Customer;

        	let returnValue;
            let phoneReplace = (app.getForm('formlp.profile.customer.phone').value()).replace(/-/g,'');
            app.getForm('formlp.profile.customer').setValue('phone', phoneReplace);
            app.getForm('formlp.profile.address').setValue('country', 'JP');
            app.getForm('formlp.profile.address').setValue('lastname', app.getForm('formlp.profile.customer.lastname').value());
            app.getForm('formlp.profile.address').setValue('firstname', app.getForm('formlp.profile.customer.firstname').value());
            app.getForm('formlp.profile.address').setValue('phone', phoneReplace);
            app.getForm('formlp.profile.address').setValue('txLastNameKana', app.getForm('formlp.profile.custom.txLastNameKana').value());
            app.getForm('formlp.profile.address').setValue('txFirstNameKana', app.getForm('formlp.profile.custom.txFirstNameKana').value());

            var year = app.getForm('formlp.profile.customer.bml.year').value();
            var month = app.getForm('formlp.profile.customer.bml.month').value()-1;
            var day = app.getForm('formlp.profile.customer.bml.day').value();

            var date = new Date(year, month, day);
            var birthdate = new dw.util.Calendar(date);
            app.getForm('formlp.profile.customer').setValue('birthday', birthdate.time);

            email = app.getForm('formlp.profile.customer.email').value();
            password = app.getForm('formlp.profile.login.password').value();
            Customer = app.getModel('Customer');
          	//ここから先は共通の注文処理のため、セッションにフラグを設定
           	session.custom.txOrderFromFormLp = true;
            returnValue = Customer.createAccount(email, password, app.getForm('formlp.profile'));
            if(!returnValue.error){
            	dw.system.Logger.info("１０１０");
            	orderNo =  app.getForm('formlp.profile.customer.orderNo').value();
                isValid = true;
                if (orderNo) {
                	dw.system.Logger.info("１２１２");
                    var orders = OrderMgr.searchOrders('orderNo={0} AND status!={1}', 'creationDate desc', orderNo,
                                        dw.order.Order.ORDER_STATUS_REPLACED);
                    if (orders) {
                    	dw.system.Logger.info("１３１３");
                        var foundOrder = orders.next();
                        Transaction.wrap(function(){
                            foundOrder.customer = returnValue.item;
                        })
                    }
                }
            }else{
                isValid = false;
                var msList='';
                msList += ',' + returnValue.item;
            }



            //Customerが作られると、この後COPlaceOrder.js start()の中Cart.get()でBasketMgr.getCurrentBasket();でPersonal dataがクリアされてとれるため
            //Customer作成後に再度配送情報の設定を実施

            //商品情報は取り直さない
            var cart = app.getModel('Cart').goc();
            //cart.clearCart(null);
            //var pid = app.getForm('formlp.selectedproductid').value();
            //var qty = app.getForm('formlp.selectedproductqty').value();
            //cart.addProductToCart();

            //var upsellpids = app.getForm('formlp.upsellpids').value();
            //if(upsellpids && upsellpids !== undefined){
            //	var prodList = parseUpsellProductList(upsellpids);
            //}


            var delivedate = session.forms.formlp.delivedate.value;
            var checkdelivedate = session.forms.formlp.checkdelivedate.value;
            var delivetime = session.forms.formlp.delivetime.value;
            var checkdelivetime = session.forms.formlp.checkdelivetime.value;
            var selectedProductid = app.getForm('formlp.selectedproductid').value();
            //希望日時のチェックと値の有無が一致しているか確認
            var allProductLineItems = cart.object.getAllProductLineItems();
            for (var it = allProductLineItems.iterator(); it.hasNext();){
                var productInCart = it.next();
                if(selectedProductid == productInCart.productID){
                    var cartCheckdelivedate = 0;
                    var cartCheckdelivetime = 0;
                    if('txDeliveryYmd' in productInCart.custom && productInCart.custom.txDeliveryYmd !== null && !empty(productInCart.custom.txDeliveryYmd)) cartCheckdelivedate = 1;
                    if('txDeliveryHm' in productInCart.custom && productInCart.custom.txDeliveryHm !== null && !empty(productInCart.custom.txDeliveryHm)) cartCheckdelivetime = 1;
                    //希望日チェック
                    if(checkdelivedate != cartCheckdelivedate){
                        session.forms.formlp.checkdelivedate.value = cartCheckdelivedate;
                    }else if(checkdelivedate == 1 && cartCheckdelivedate == 1){
                        var deliveryYmd = productInCart.custom.txDeliveryYmd;
                        var delivedatecCal = new dw.util.Calendar(delivedate);
                        delivedatecCal.setTimeZone('Asia/Tokyo');
                        var deliveryDateYmd = dw.util.StringUtils.formatCalendar(delivedatecCal,'yyyy-MM-dd');
                        if(!deliveryYmd.equals(deliveryDateYmd)){
                            var replaceDeliveryYmd = deliveryYmd.replace(/\-/g,'\/');
                            session.forms.formlp.delivedate.value = new Date(replaceDeliveryYmd);
                        }
                    }
                    //希望時間チェック
                    if(checkdelivetime != cartCheckdelivetime){
                        session.forms.formlp.checkdelivetime.value = cartCheckdelivetime;
                    }else if(checkdelivetime == 1 && cartCheckdelivetime == 1){
                        var deliveryHm = productInCart.custom.txDeliveryHm;
                        if(!deliveryHm.equals(delivetime)){
                            session.forms.formlp.delivetime.value = deliveryHm;
                        }
                    }
                }
            }

            //カートに配送情報を設定する
            handleShippingSettings(cart);

            // Mark step as fulfilled.
            session.forms.singleshipping.fulfilled.value = true;

            if(cart.object.totalGrossPrice.value == 0){
            	//注文総額が0円の場合、フォームの支払い方法を上書きする（フロントページでは商品選択があり注文情報確定しておらず支払い方法非表示制御ができないため）
            	app.getForm('billing').object.paymentMethods.selectedPaymentMethodID.setValue(PaymentInstrument.METHOD_GIFT_CERTIFICATE);
            }

            var COBilling = app.getController('COBilling');

            //@todo
            //COBilling.resetPaymentForms
            COBilling.resetPaymentForms;
            dw.system.Logger.info("selectedPaymentMethodID : " + app.getForm('billing').object.paymentMethods.selectedPaymentMethodID.value);


        	//カートに支払方法を設定する
            if (COBilling.HandlePaymentSelection(cart).error) {
            	dw.system.Logger.info("COBilling.HandlePaymentSelection(cart)がerror");
            	//error
            	msList += ',' + Resource.msg('hcformlp.formlp.paymenterror', 'hcformlp', null);
            	isValid = false;
            } else {
			// Mark step as fulfilled
                app.getForm('billing').object.fulfilled.value = true;
            }

            //コピーここまで

            if (!isValid) {
            	session.custom.txErrorList = msList;
            	delete session.custom.txOrderFromFormLp;
            	response.redirect(app.getForm('formlp.errredirect').value());
            } else {
            	//注文処理実施
            	var COSummary = app.getController('COSummary');
            	dw.system.Logger.info("１４１４");
            	COSummary.SubmitfromLP();
            }

        },

        //アップセル商品入れ替え
        upsell: function() {
        	//カートに商品を投入する
            var cart = app.getModel('Cart').goc();
            //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
            var removeProductLineItems = [];
            for (var it = cart.object.getAllProductLineItems().iterator(); it.hasNext();){
                var target = it.next();
                if(target.product != null){
                    removeProductLineItems.push({
                        product: target.product,
                        quantityValue: target.quantityValue
                    });
                }
            }
            //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.
            cart.clearCart(null);
            cart.addProductToCart();
            //配送方法を再度決め直す
            Transaction.wrap(function () {
            	cart.calculate();
            });

            var pid = app.getForm('formlp.selectedproductid').value();
            var qty = app.getForm('formlp.selectedproductqty').value();
            var upsellpids = app.getForm('formlp.upsellpids').value();
            var adjustedPrices = app.getForm('formlp.adjustedprices').value();
            if(upsellpids && upsellpids !== undefined){
            	var prodList = parseUpsellProductList(upsellpids,adjustedPrices);
            }

    		if(typeof adjustedPrices !== 'undefined' && adjustedPrices !== null){
    			var priceArr = parseAdjustedPriceList(adjustedPrices,pid,qty,cart);
    		}

            //精査及び確認画面で利用するためフォームへ登録
            //app.getForm('formlp.checkdelivedate').object.setHtmlValue(params.isDeliveDate);
            //app.getForm('formlp.checkdelivetime').object.setHtmlValue(params.isDeliveTime);

            var isValid = true;
            var msList='';
            var nopayment = false;
            var includeSubsc = false;

            //カートに配送情報を設定する
        	handleShippingSettings(cart);

        	//日時指定不可商品がカートにある場合
        	for (var it = cart.object.getAllProductLineItems().iterator(); it.hasNext();){
        		var productInCart = it.next();
        		if(productInCart.product != null){
        			if(productInCart.product.custom.txHideDelivedateSelect && (session.forms.formlp.checkdelivedate.value == '1' || session.forms.formlp.checkdelivetime.value == '1')){
        				msList += ',' + Resource.msg('hcformlp.formlp.delivedateselecterror', 'hcformlp', null);
            			isValid = false;
        			}

        			//定期商品があるかどうかを記録しておく
        			if(!includeSubsc && !productInCart.bonusProductLineItem && productInCart.product.custom.txShippingProductType.value == '2'){
        				includeSubsc = true;
        			}
        		}
        	}

        	//ネコポスor郵便の場合に配送希望を選択していたらエラーを返す
        	for (var it = cart.object.getShipments().iterator(); it.hasNext();){
        		var cartshipment = it.next();
        		if((cartshipment.getShippingMethod().ID.indexOf("txDelivery") != 0) && (session.forms.formlp.checkdelivedate.value == '1' || session.forms.formlp.checkdelivetime.value == '1')){
        			//ネコポスで日付指定されていても、定期商品の場合はエラーとしない
        			if(!includeSubsc){
	        			msList += ',' + Resource.msg('hcformlp.formlp.delivedateselecterror.notdelivery', 'hcformlp', null);
	        			isValid = false;
        			}
        		}
        	}

            //お届け希望日用カレンダーの有効範囲
            var maxDate = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryMaxDate');
            var minDate = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryMinDate');
            for(let i = 0; i < prodList.length; i++){
                if(prodList[i].product != null && !empty(prodList[i].product)){
                    prodList[i].minDate = minDate;
                    prodList[i].maxDate = maxDate;
                    var availability = prodList[i].product.getAvailabilityModel();
                    if(availability != null && !empty(availability)){
                        var inventoryRecord = availability.getInventoryRecord();
                        if(inventoryRecord && inventoryRecord.preorderable){
                            var inStockDate = inventoryRecord.inStockDate;
                            if(inStockDate != null && !empty(inStockDate)){
                                var inStockCal = new dw.util.Calendar();
                                inStockCal.setTimeZone('Asia/Tokyo');
                                inStockCal.setTime(inStockDate);
                                inStockDate = dw.util.StringUtils.formatCalendar(inStockCal,'yyyy/MM/dd');
                                inStockDate = new Date(inStockDate);
                                var dateRange = dw.system.Site.getCurrent().getCustomPreferenceValue('txShippingDeliveryDateRange');
                                var today =  new dw.util.Calendar();
                                today .setTimeZone('Asia/Tokyo');
                                today = dw.util.StringUtils.formatCalendar(today,'yyyy/MM/dd');
                                today = new Date(today);
                                var min = (inStockDate - today)/86400000;
                                if(minDate < min){
                                    prodList[i].minDate = min;
                                }
                                prodList[i].maxDate = prodList[i].minDate + dateRange;
                            }
                        }
                    }
                    if(session.forms.formlp.checkdelivedate.value == '1'){
                        let selectDelivedate = session.forms.formlp.delivedate.value;
                        let selectDeliveCal =  new dw.util.Calendar();
                        selectDeliveCal .setTimeZone('Asia/Tokyo');
                        selectDeliveCal.setTime(selectDelivedate);
                        if(app.getController('COShipping').DeliveCalendarScope(selectDeliveCal,prodList[i].maxDate,prodList[i].minDate)){
                            prodList[i].deliveScope = 1;
                        }else{
                            prodList[i].deliveScope = 0;
                        }
                    }else{
                        prodList[i].deliveScope = 0;
                    }
                }
            }
        	//【FFHC v1.0】2.3.4. 支払方法　Start.(Cart.js show()から移植＋改修)
            //顧客、国コード、合計金額で利用可能な支払方法が無い場合はエラーメッセージ表示
            var countryCode = Countries.getCurrent({
                CurrentRequest: {
                    locale: request.locale
                }
            }).countryCode;

            if((priceArr != null && priceArr[1] ==0 ) || cart.object.totalGrossPrice.value == 0){
            	//注文総額が0円の場合、フォームの支払い方法を上書きする（確認画面上、アップセル商品選択があり注文情報確定しておらず支払い方法非表示制御ができないため）
            	app.getForm('billing').object.paymentMethods.selectedPaymentMethodID.setValue(PaymentInstrument.METHOD_GIFT_CERTIFICATE);
            }else{
            	var selectedPaymentMethodID = app.getForm('billing').object.paymentMethods.selectedPaymentMethodID;

            	//アップセルで有料商品選択時に支払方法未入力の場合（ex.0円商品からのアップセル）、エラーを返す
                var cardNumber = app.getForm('billing').object.paymentMethods.creditCard.number.value;
                var cardSecurityCode = app.getForm('billing').object.paymentMethods.creditCard.cvn.value;
                if(selectedPaymentMethodID.value == 'VERITRANS_CREDIT_CARD' && (cardNumber == null || cardSecurityCode == null)){
                	msList += ',' + Resource.msg('hcformlp.formlp.paymentmethoderror.none', 'hcformlp', null);
                	isValid = false;
                	nopayment = true;
                }

            	if(dw.order.PaymentMgr.getApplicablePaymentMethods(customer,countryCode,cart.object.adjustedMerchandizeTotalPrice.value).size() == 0){
            		msList += ',' + Resource.msg('hcformlp.formlp.paymentmethoderror', 'hcformlp', null);
            		isValid = false;
            	}else{

            		//ネコポスor郵便の場合に支払方法CODを選択していたらエラーを返す
            		for (var it = cart.object.getShipments().iterator(); it.hasNext();){
            			var cartshipment = it.next();
            			if((cartshipment.getShippingMethod().ID.indexOf("txDelivery") != 0) && selectedPaymentMethodID.value.equals('COD')){
            				msList += ',' + Resource.msg('hcformlp.formlp.paymentmethoderror.cod', 'hcformlp', null);
            				isValid = false;
            			}
            		}
            		if(isValid){
            			var methods = dw.order.PaymentMgr.getApplicablePaymentMethods(customer,countryCode,cart.object.adjustedMerchandizeTotalPrice.value);

            			var methodIDs = new Array();
            			for (var i = 0; i < methods.length; i++) {
            				methodIDs.push(methods[i].getID().toString());
            				dw.system.Logger.info("methods[i].getID().toString() : " + methods[i].getID().toString());
            				if(methods[i].getID().toString()===selectedPaymentMethodID.value){dw.system.Logger.info("等しい : " + methods[i].getID().toString());}

            			}
            			dw.system.Logger.info("methodIDs.length : " + methodIDs.length);
            			if(methodIDs.indexOf(selectedPaymentMethodID.value) == -1){
            				dw.system.Logger.info("typeof : " + typeof(selectedPaymentMethodID.value));

            				msList += ',' + Resource.msg('hcformlp.formlp.paymentmethoderror2', 'hcformlp', null);
            				isValid = false;
            			}
            		}
            	}
            }



            var COBilling = app.getController('COBilling');

            //これを呼びたいのでローカルメソッド化した後に実施
            COBilling.resetPaymentForms;
            dw.system.Logger.info("inupsell selectedPaymentMethodID : " + app.getForm('billing').object.paymentMethods.selectedPaymentMethodID.value);

        	//カートに支払方法を設定する
            if (!nopayment && COBilling.HandlePaymentSelection(cart).error) {
            	//error
            	msList += ',' + Resource.msg('hcformlp.formlp.paymenterror', 'hcformlp', null);
            	isValid = false;
            } else {
			// Mark step as fulfilled
                app.getForm('billing').object.fulfilled.value = true;
            }

            var veritransCardList = request.httpParameterMap.veritransCardList.value;
            if(veritransCardList == null && app.getForm('billing').object.paymentMethods.selectedPaymentMethodID.value.equals('VERITRANS_CREDIT_CARD')){
            	veritransCardList = "AddNewCard";
            }


        	if(!isValid){
        		session.custom.txErrorList = msList;
        		//エラーで1ページ目に戻った際、選択していた商品が選択された状態になるよう以下を設定する
        		app.getForm('formlp.selectedproductid').object.setHtmlValue(removeProductLineItems[0].product.ID);
        		app.getForm('formlp.selectedproductqty').object.setHtmlValue(removeProductLineItems[0].quantityValue);
                //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
                var txRemoveProductTag = '';
                for (var i = 0; i < removeProductLineItems.length; i++) {
                    var removeTarget = removeProductLineItems[i];
                    if (txRemoveProductTag.length > 0) {
                        txRemoveProductTag = txRemoveProductTag + ';';
                    }
                    txRemoveProductTag = txRemoveProductTag + removeTarget.product.ID + ',' + removeTarget.quantityValue
                }
                session.custom.txRemoveProductTag = txRemoveProductTag;
                //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.
    			response.redirect(app.getForm('formlp.errredirect').value());
        	}


            //確認画面で利用するためフォームへ登録
            app.getForm('formlp.ischangeupsellproduct').object.setHtmlValue("true");
        	app.getView({
        		ContinueURL: URLUtils.https('HcFormLp-OrderConfirmation'),
        		upsellProducts: prodList,
        		priceArr: priceArr,
        		optDispShipDay: app.getForm('formlp.optdispshipday').object.getValue(),
        		optDispShipTime: app.getForm('formlp.optdispshiptime').object.getValue(),
        		Basket: cart.object,
        		veritransCardList: veritransCardList,
                //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 Start.
                isFormLPSummary: true,
                removeProductLineItems: removeProductLineItems
                //【FFHC v1.0】【フォーム一体型LPで商品選択変更した場合にremove_from_cartデータを送信する】 #6556 End.
            }).render('product/formlpsummary');
        },

        //支払い方法変更

        //配送予定日時変更


        //バリデーションエラー時
        error: function() {
        	var profile = app.getForm('formlp.profile');

            var msList = Resource.msg('address.invalid', 'forms', null);

            if(!profile.object.customer.lastname.valid){
                msList += ',' + Resource.msg('profile.lastname', 'forms', null);
            };
            if(!profile.object.customer.firstname.valid){
                msList += ',' + Resource.msg('profile.firstname', 'forms', null);
            };
            if(!profile.object.custom.txLastNameKana.valid){
                msList += ',' + Resource.msg('profile.lastnamekana', 'forms', null);
            };
            if(!profile.object.custom.txFirstNameKana.valid){
                msList += ',' + Resource.msg('profile.firstnamekana', 'forms', null);
            };
            if(!profile.object.customer.bml.year.valid || !profile.object.customer.bml.month.valid
             || !profile.object.customer.bml.day.valid){
                msList += ',' + Resource.msg('profile.dob', 'forms', null);
            };
            if(!profile.object.customer.gender.valid){
                msList += ',' + Resource.msg('profile.gender', 'forms', null);
            };
            if(!profile.object.customer.phone.valid){
                msList += ',' + Resource.msg('account.user.registration.phon', 'account', null);
            };
            if(!profile.object.address.postal.valid){
                msList += ',' + Resource.msg('resource.postalcode', 'forms', null);
            };
            if(!profile.object.address.states.state.valid){
                msList += ',' + Resource.msg('resource.state', 'forms', null);
            };
            if(!profile.object.address.city.valid){
                msList += ',' + Resource.msg('resource.city', 'forms', null);
            };
            if(!profile.object.address.address1.valid){
                msList += ',' + Resource.msg('account.user.registration.address1', 'account', null);
            };
            if(!profile.object.address.address2.valid){
                msList += ',' + Resource.msg('account.user.registration.address2', 'account', null);
            };
            if(!profile.object.custom.txSuppliersName.valid){
                msList += ',' + Resource.msg('account.user.registration.company', 'account', null);
            };
            if(!profile.object.custom.txSuppliersID.valid){
                msList += ',' + Resource.msg('account.user.registration.suppliersID', 'account', null);
            };
            if(!profile.object.customer.email.valid ||
               !profile.object.customer.emailconfirm.valid){
               msList += ',' + Resource.msg('profile.email', 'forms', null);
            };
            if(!profile.object.login.password.valid ||
               !profile.object.login.passwordconfirm.valid){
               msList += ',' + Resource.msg('label.password', 'forms', null);
            };

            session.custom.txErrorList = msList;
            response.redirect(app.getForm('formlp.errredirect').value());
        }
    });
}

/**
 * 商品ID文字列をリストにパース
 * @param productIds
 * @returns
 */
function parseProductList(productIds,adjustedPrices) {
	//adjustedPrices指定があれば値を取得
	if(adjustedPrices.stringValue !== null){
		var priceArr = adjustedPrices.stringValue.split(' ');
	}
	//商品モデルを取得
    var Product = app.getModel('Product');
    var prodList = new dw.util.ArrayList();
	//数量パラメータの解析
	//スペースで分割
	var pidArr = productIds.split(' ');

	for (var i = 0;i < pidArr.length;i++) {
		//オプション部分を分割
		var podTmp = pidArr[i].split('|');
		var pidDetailArr = podTmp[0].split('_');
		var pid = pidDetailArr[0];
		var optAdjustedPrice = null;
		if(typeof priceArr !== 'undefined' && priceArr !== null && priceArr.indexOf(pid) > -1){
			var optAdjustedPrice = priceArr[priceArr.indexOf(pid) + 1];
		}

		var qty1 = '1';
		if (pidDetailArr.length > 1) {
			qty1 = pidDetailArr[1];
		}
		var qty2 = '10';
		if (podTmp.length > 1) {
			if (parseInt(podTmp[1]) < 11 && parseInt(podTmp[1]) > 0){
				qty2 = podTmp[1];
			}
		}
		try {
    		var p = Product.get(pid).object;
    		//購入数制限の考慮(1回あたり)
    		if(p.custom.txMaxQuantityOneTime != null){
    			if (parseInt(p.custom.txMaxQuantityOneTime) < parseInt(qty2)){
    				qty2 = p.custom.txMaxQuantityOneTime;
    			}
    		}
    		//購入数制限の考慮(1人あたり)
    		if(p.custom.txPurchasableCntPerPerson != null){
    			if (parseInt(p.custom.txPurchasableCntPerPerson) < parseInt(qty2)){
    				qty2 = p.custom.txPurchasableCntPerPerson;
    			}
    		}
    		if (parseInt(qty2) == 1){
				qty1 = '1';
    		}else if(parseInt(qty2) < parseInt(qty1)){
    			qty1 = '0'+qty2;
			}
    	    prodList.add({product: p,qty1: qty1, qty2: qty2, optAdjustedPrice: optAdjustedPrice});
		} catch (e) {
			//商品が存在しないケースは無視
		}
	}
	return prodList;
}

/**
 * アップセル商品ID文字列をリストにパース
 * @param productIds
 * @returns
 */
function parseUpsellProductList(productIds,adjustedPrices) {
	//adjustedPrices指定があれば値を取得
	if(adjustedPrices !== null){
		var priceArr = adjustedPrices.split(' ');
	}
	//商品モデルを取得
    var Product = app.getModel('Product');
    var prodList = new dw.util.ArrayList();
	//数量パラメータの解析
	//スペースで分割
	var pidArr = productIds.split(' ');

	for (var i = 0;i < pidArr.length;i++) {
		//オプション部分を分割
		var upsellPodTmp = pidArr[i].split('-');
		var podTmp = upsellPodTmp[0].split('|');
		var pidDetailArr = podTmp[0].split('_');
		var pid = pidDetailArr[0];
		var optionKey = '';
		var optionVal = '';
		var optAdjustedPrice = null;
		if(typeof priceArr !== 'undefined' && priceArr !== null && priceArr.indexOf(pid) > -1){
			var optAdjustedPrice = priceArr[priceArr.indexOf(pid) + 1];
		}

		var qty1 = '1';
		if (pidDetailArr.length > 1) {
    		qty1 = pidDetailArr[1];
		}
		var qty2 = '10';
		if (podTmp.length > 1) {
			qty2 = podTmp[1];
		}

		if (upsellPodTmp.length > 1) {
			var pidOptionArr = upsellPodTmp[1].split(':');
			optionKey = pidOptionArr[0];
			if (pidOptionArr.length > 1) {
				optionVal = pidOptionArr[1];
			}
		}
		try {
    		var p = Product.get(pid).object;
    		//購入数制限の考慮(1回あたり)
    		if(p.custom.txMaxQuantityOneTime != null){
    			if (parseInt(p.custom.txMaxQuantityOneTime) < parseInt(qty2)){
    				qty2 = p.custom.txMaxQuantityOneTime;
    			}
    		}
    		//購入数制限の考慮(1人あたり)
    		if(p.custom.txPurchasableCntPerPerson != null){
    			if (parseInt(p.custom.txPurchasableCntPerPerson) < parseInt(qty2)){
    				qty2 = p.custom.txPurchasableCntPerPerson;
    			}
    		}
    		if (parseInt(qty2) == 1){
				qty1 = '1';
    		}else if(parseInt(qty2) < parseInt(qty1)){
    			qty1 = '0'+qty2;
			}
    	    prodList.add({product: p,qty1: qty1, qty2: qty2, opk: optionKey, opv: optionVal, optAdjustedPrice: optAdjustedPrice});
		} catch (e) {
			//アップセル商品が存在しないケースは無視
		}
	}
	return prodList;
}


function parseAdjustedPriceList(adjustedPrices,pid,qty,cart) {
	var priceArr = adjustedPrices.split(' ');

	var optTotalAdjustedPrice;
	var Product = app.getModel('Product');
	var p = Product.get(pid).object;
	//配列1番目に、指定された割引金額×個数の金額を追加する。（pidが割引対象でない場合、定価総額を追加する。）
	if(priceArr.indexOf(pid) > -1){
		optTotalAdjustedPrice = priceArr[priceArr.indexOf(pid)+1];
		optTotalAdjustedPrice = optTotalAdjustedPrice*parseInt(qty);

	}else{
		if(p.productSet){
			//pidがセット品のとき
			optTotalAdjustedPrice = parseInt(p.longDescription)*parseInt(qty);
		}else{
			optTotalAdjustedPrice = cart.object.getAllProductLineItems(pid)[0].getPrice()
		}
	}
	priceArr.unshift(optTotalAdjustedPrice);

	//配列0番目に定価×個数の金額を追加する
	if(!p.productSet){
		priceArr.unshift(cart.object.getAllProductLineItems(pid)[0].getPrice());
		if(p.productSetProduct){
			if(priceArr.indexOf(pid) > -1){
    			adjTotal = parseInt(priceArr[priceArr.indexOf(pid)+1])*parseInt(qty);
    			priceArr.splice(priceArr.indexOf(pid)+2,0,adjTotal);
    		}
		}
	}else{
		//pidがセット品のときlongDescription×個数の金額を追加する。また、構成商品の指定割引額×個数を列に足していく。
		priceArr.unshift(parseInt(p.longDescription)*parseInt(qty));
		for (var it = p.getProductSetProducts().iterator(); it.hasNext();){
    		var productSetProduct = it.next();
    		var adjTotal;

    		if(priceArr.indexOf(productSetProduct.ID) > 0){
    			adjTotal = parseInt(priceArr[priceArr.indexOf(productSetProduct.ID)+1])*parseInt(qty);
    			priceArr.splice(priceArr.indexOf(productSetProduct.ID)+2,0,adjTotal);
    		}else{

    			adjTotal = parseInt(productSetProduct.priceModel.price)*parseInt(qty);
    			priceArr.push(productSetProduct.ID);
    			priceArr.push(parseInt(productSetProduct.priceModel.price));
    			priceArr.push(adjTotal);

    		}


		}
	}

	return priceArr;
}

/**
 * Initializes the credit card list by determining the saved customer payment methods for the current locale.
 * @param {module:models/CartModel~CartModel} cart - A CartModel wrapping the current Basket.
 * @return {object} JSON object with members ApplicablePaymentMethods and ApplicableCreditCards.
 */
function initCreditCardList(optDispPaymentMethods) {
//  var paymentAmount = cart.getNonGiftCertificateAmount();
    countryCode = Countries.getCurrent({
        CurrentRequest: {
            locale: request.locale
        }
    }).countryCode;

    //0円だと支払方法が出ないので、1円を強制的に設定
    var paymentAmount = new dw.value.Money(1,countryCode);
    var countryCode;
    var applicablePaymentMethods;
    var applicablePaymentCards;
    var applicableCreditCards;

    applicablePaymentMethods = PaymentMgr.getApplicablePaymentMethods(customer, countryCode, paymentAmount.value);
    applicablePaymentCards = PaymentMgr.getPaymentMethod(PaymentInstrument.METHOD_CREDIT_CARD).getApplicablePaymentCards(customer, countryCode, paymentAmount.value);

    app.getForm('billing').object.paymentMethods.creditCard.type.setOptions(applicablePaymentCards.iterator());

    applicableCreditCards = null;

    //パラメータに従い、支払い方法フィルタ実施
    var deleteList = new dw.util.ArrayList();
    for (var it = applicablePaymentMethods.iterator(); it.hasNext();) {
    	var pm = it.next();
    	if (optDispPaymentMethods.toString().indexOf(pm.ID) < 0) {
    		deleteList.add(pm);
    	}
    }
    applicablePaymentMethods.removeAll(deleteList);

    if (customer.authenticated) {
        var profile = app.getModel('Profile').get();
        if (profile) {
            applicableCreditCards = profile.validateWalletPaymentInstruments(countryCode, paymentAmount.getValue()).ValidPaymentInstruments;
        }
    }

    return {
        ApplicablePaymentMethods: applicablePaymentMethods,
        ApplicableCreditCards: applicableCreditCards
    };
}

/**
 * Handles the selected shipping address and shipping method. Copies the
 * address details and gift options to the basket's default shipment. Sets the
 * selected shipping method to the default shipment.
 *
 * @transactional
 * @param {module:models/CartModel~CartModel} cart - A CartModel wrapping the current Basket.
 */
function handleShippingSettings(cart) {
    Transaction.wrap(function () {
        var defaultShipment, shippingAddress;
        defaultShipment = cart.getDefaultShipment();
        shippingAddress = cart.createShipmentShippingAddress(defaultShipment.getID());

        var deliveryAddressKbn = '0';

        shippingAddress.setFirstName(session.forms.formlp.profile.customer.firstname.value);
        shippingAddress.setLastName(session.forms.formlp.profile.customer.lastname.value);
        shippingAddress.setAddress1(session.forms.formlp.profile.address.address1.value);
        shippingAddress.setAddress2(session.forms.formlp.profile.address.address2.value);
        shippingAddress.setCity(session.forms.formlp.profile.address.city.value);
        shippingAddress.setPostalCode(session.forms.formlp.profile.address.postal.value);
        shippingAddress.setStateCode(session.forms.formlp.profile.address.states.state.value);
        shippingAddress.setCountryCode('JP');
        shippingAddress.setPhone(session.forms.formlp.profile.customer.phone.value);

        shippingAddress.custom.txLastNameKana = session.forms.formlp.profile.custom.txLastNameKana.value;
        shippingAddress.custom.txFirstNameKana = session.forms.formlp.profile.custom.txFirstNameKana.value;
        //shippingAddress.getCustom(会社名) = xxx;
        //shippingAddress.getCustom(部署名) = xxx;


        //【FFHC v1.0】 2.3.1. 決済導線　Start.

        //各商品に配送日時を設定
        var allProductLineItems = cart.object.getAllProductLineItems();
        var deliveryDate = null;
        var deliveryTime = null;

        //【FFHC v1.0】 2.4.4. フォーム一体型LP　Start.
        //存在しないフォームsingleshipping参照を回避
        //if(session.forms.singleshipping.shippingSelect.value == '02'){
        //	deliveryDate = request.httpParameterMap.teikiDeliveryDate.value;
        //	deliveryTime = request.httpParameterMap.teikiDeliveryTime.value;
        //}else{
        	//フォーム名をsingleshippingからformlpに変更
        	//deliveryDate = session.forms.formlp.delivedate.value != null ? dw.util.StringUtils.formatCalendar(new dw.util.Calendar(session.forms.formlp.delivedate.value),'yyyy-MM-dd') : null;
        	//配送日時選択不可の場合、もしくは[希望しない]を選択している場合はNULL
        	if(session.forms.formlp.checkdelivedate.value == '1'){
        		var cal = new dw.util.Calendar(session.forms.formlp.delivedate.value);
        		cal.setTimeZone('Asia/Tokyo');
        		deliveryDate = dw.util.StringUtils.formatCalendar(cal,'yyyy-MM-dd');
        	}else{
        		deliveryDate = null;
        	}

        	if(session.forms.formlp.checkdelivetime.value == '1'){
        		deliveryTime = session.forms.formlp.delivetime.value;
        	}else{
        		deliveryTime = null;
        	}
        	dw.system.Logger.info("handleshipping deliveryTime : " + deliveryTime);
        //}
        //【FFHC v1.0】 2.4.4. フォーム一体型LP　End.
        //【FFHC v1.0】 2.4.4. フォーム一体型LP　Start.
        //配送方法確定後に設定する
    	//for each(var productInCart in allProductLineItems.iterator()){
	    //	productInCart.custom.txDeliveryYmd = deliveryDate;
	    //	productInCart.custom.txDeliveryHm = deliveryTime;
        //}
    	//【FFHC v1.0】 2.4.4. フォーム一体型LP　End.


        //配送会社の決定
        var shipments = cart.object.getShipments().iterator();
        while (shipments.hasNext()) {
        	var shipment = shipments.next();
        	//セッションに疑似的デフォルト配送会社を持っておく(ゲストかデフォが決まってない会員)
        	//【FFHC v1.0】 2.4.4. フォーム一体型LP　Start.
            //存在しないcustomer参照処理を回避
        	//if(!customer.authenticated || customer.profile.custom.txDeliveryCompany.value == null){
        		var deliveryCompanyKbn = '02';
    			var eastJapan = dw.system.Site.getCurrent().getCustomPreferenceValue('txEastJapan');
    			var yamatoDeliveryTime = dw.system.Site.getCurrent().getCustomPreferenceValue('txYamatoDeliveryTime');
    			//存在しないcustomer参照処理を回避
    			//var customerPrefecture = customer.authenticated ? customer.getAddressBook().getAddress(Resource.msg('account.address.id.default.sfsc', 'account', null)).getStateCode() : shippingAddress.getStateCode();
    			var customerPrefecture = shippingAddress.getStateCode();

    			if(shipment.getShippingMethod().ID.indexOf("txDelivery") != 0){//ネコポスor郵便の場合
        			deliveryCompanyKbn = (eastJapan.indexOf(customerPrefecture) >= 0) ? '03' : '02';
        			dw.system.Logger.info("ネコポスか郵便判定　deliveryCompanyKbn : " + deliveryCompanyKbn);
        			//LPの場合希望日時指定入力時には配送方法確定しておらず、配送方法に関わらず希望日時入力可となっている。そのため配送方法確定後にクリアする必要がある
        			//ネコポス配送でも定期商品を含む場合は日付指定可能とする
        			var includeSubsc = false;

        			for (var it = allProductLineItems.iterator(); it.hasNext();){
                		var productInCart = it.next();
                		if(productInCart.product != null && productInCart.product.custom.txShippingProductType.value == '2'){
                			includeSubsc = true;
                			break;
                		}
        			}

        			if(!includeSubsc) deliveryDate = null;
        			deliveryTime = null;
        		} else {//宅配の場合
        			//フォーム名をsingleshippingからformlpに変更
        			if((session.forms.formlp.checkdelivetime.value == '1' && yamatoDeliveryTime.indexOf(session.forms.formlp.delivetime.value) != 0) || eastJapan.indexOf(customerPrefecture) == 0){
        				deliveryCompanyKbn = '03';
        				dw.system.Logger.info("宅配判定　deliveryCompanyKbn : " + deliveryCompanyKbn);
        			}
        		}
    			session.custom.deliveryCompanyKbnTmp = deliveryCompanyKbn;
        	//}
        	//配送方法と、疑似的デフォルト配送会社から配送会社を決定(注文情報に登録する用　会員情報を更新するのは最後)

        	if(shipment.getShippingMethod().ID.indexOf("txNekopos") == 0) shipment.custom.txDeliveryCompanyKbn = '02';
        	else if(shipment.getShippingMethod().ID.indexOf("txPostIn") == 0) shipment.custom.txDeliveryCompanyKbn = '04';
        	else {
        		//存在しないcustomer参照処理を回避
        		//if(!customer.authenticated || customer.profile.custom.txDeliveryCompany.value == null) shipment.custom.txDeliveryCompanyKbn = session.custom.deliveryCompanyKbnTmp;
        		//else shipment.custom.txDeliveryCompanyKbn = customer.profile.custom.txDeliveryCompany.value;
        		shipment.custom.txDeliveryCompanyKbn = session.custom.deliveryCompanyKbnTmp;
        		//【FFHC v1.0】 2.4.4. フォーム一体型LP　End.
        	}

        	//お届け先区分を設定　自宅：0　別送先：1
        	shipment.custom.txDeliveryKbn = deliveryAddressKbn;

        	//LPの場合希望日時指定入力時には配送方法確定しておらず、配送方法に関わらず希望日時入力可となっている。そのため配送方法確定後にクリアする必要がある
        	for (var it = allProductLineItems.iterator(); it.hasNext();){
        		var productInCart = it.next();
        		productInCart.custom.txDeliveryYmd = deliveryDate;
    	    	productInCart.custom.txDeliveryHm = deliveryTime;
        	}

        //	//商品ごとのアップセル・カウンセリング設定
        //	if(session.custom.isOnBehalf){
        //		//代理ログインの場合はカート画面で入力された値を表示
        //		var i = 0;
        //		for each(var productInCart in allProductLineItems.iterator()){
        //			if(productInCart.product != null){
	    //    			productInCart.custom.txIsUpselling = session.forms.cart.shipments[0].items[i].txIsUpselling.value;
	    //    			productInCart.custom.txIsCounseling = session.forms.cart.shipments[0].items[i].txIsCounseling.value;
	    //    			i++;
        //			}
        //        }
        //	}else{
        			//代理ログインでない場合は全てfalseを設定←LPの場合必ず代理ログインではない
        			for (var it = allProductLineItems.iterator(); it.hasNext();){
        				var productInCart = it.next();
        				productInCart.custom.txIsUpselling = false;
        				productInCart.custom.txIsCounseling = false;

        				//定期商品を含むかどうか
        				if(productInCart.product != null && !productInCart.bonusProductLineItem && productInCart.product.custom.txShippingProductType.value == '2'){
        					if(productInCart.custom.txTeikiKind.value == null || productInCart.custom.txTeikiKind.value == ''){
        						hcLogger.fatal('teiki attribute is empty', null, '');
        						dw.system.Logger.info("teiki attribute is empty. (Form LP)");
        						for (var prop in session.getCustom()) {
        							dw.system.Logger.info(prop + "：" + session.getCustom()[prop]);
        						}

        						//定期属性種別がこの時点で空の場合、セットする
        						if(productInCart.getOptionProductLineItems().length > 0){
        							var options = productInCart.getOptionProductLineItems().iterator();
        							var option;
        							while(options.hasNext()){
        								option = options.next();
        								if(option.getOptionID() == 'txSubscOptPeriod'){

        									Transaction.wrap(function () {

    											//定期間隔が1.5か月、2.5か月の場合は定期種別は1、1ヶ月、2ヶ月、3ヶ月の場合は定期種別は2
        										if(option.getOptionValueID() == '1.5' || option.getOptionValueID() == '2.5'){
    												productInCart.custom.txTeikiKind = '1';

    											} else {
    												productInCart.custom.txTeikiKind = '2';

    											}
        									});
        								}
        							}
        						}
        					}
        				}
        			}
        //	}

        }



        //ギフトラッピングとまとめ制御
        //【FFHC v1.0】 2.4.4. フォーム一体型LP　Start.
        //if(session.forms.singleshipping.shippingSelect.value == '02'){
        //	cart.object.custom.txGiftWrapping = '0';
        //	cart.object.custom.txMatomeNGFlg = false;
        //}else{
        //	cart.object.custom.txGiftWrapping = session.forms.singleshipping.giftwrapping ? session.forms.singleshipping.giftwrapping.value : '0';
        //	//まとめNGフラグ　ゲストの場合は必ずtrue
        //	if(!customer.authenticated) cart.object.custom.txMatomeNGFlg = true;
        //	else if(session.custom.isOnBehalf) cart.object.custom.txMatomeNGFlg = session.forms.singleshipping.giftwrapping.value == '0' ? session.forms.singleshipping.matomeNG.value : true;
        //	else cart.object.custom.txMatomeNGFlg = session.forms.singleshipping.giftwrapping.value == '0' ? false : true;
        //}
        //フォーム一体型の場合、必ずラッピングなし、まとめNGフラグ true
        cart.object.custom.txGiftWrapping = '0';
        cart.object.custom.txMatomeNGFlg = false;
        //【FFHC v1.0】 2.4.4. フォーム一体型LP　End.

        //媒体番号(コンテンツ番号)、注文チャネル、代理注文担当ID、代理注文担当名、販売拠点
        cart.object.custom.txContentID = session.custom.txContentID;

        var deviceType = session.custom.device == 'desktop' ? 'PC' : 'SP';
        cart.object.custom.txOrderChannel = session.custom.isOnBehalf ? session.forms.cart.txOrderChannel.value : deviceType;

        cart.object.custom.txOnBehalfUID = session.custom.isOnBehalf ? session.custom.txOnBehalfUID : 'storefront';
        cart.object.custom.txOnBehalfNM = session.custom.isOnBehalf ? session.custom.txOnBehalfNM : 'storefront';
        cart.object.custom.txMarketingPlace = session.custom.isOnBehalf ? session.custom.txMarketingPlace : 'BASE001';
        //【FFHC v1.0】 2.3.1. 決済導線　End.

        //媒体番号
        cart.object.custom.txMediaNo = (session.forms.formlp.mediano.value != null ) ? session.forms.formlp.mediano.value : '';


        cart.updateShipmentShippingMethod(cart.getDefaultShipment().getID(), cart.object.getShipments().iterator().next().getShippingMethod().ID, null, null);

        //【FFHC v1.0】 x.x.x. 決済導線見直し　Start.
        //会員の場合
        var sourceAddress = null;
       	sourceAddress = shippingAddress;

        var billingAddress = cart.getBillingAddress();
        if (!billingAddress) {
        	billingAddress = cart.createBillingAddress();
        }
        billingAddress.setFirstName(sourceAddress.getFirstName());
        billingAddress.setLastName(sourceAddress.getLastName());
        billingAddress.setAddress1(sourceAddress.getAddress1());
        billingAddress.setAddress2(sourceAddress.getAddress2());
        billingAddress.setCity(sourceAddress.getCity());
        billingAddress.setPostalCode(sourceAddress.getPostalCode());
        billingAddress.setStateCode(sourceAddress.getStateCode());
        billingAddress.setCountryCode(sourceAddress.getCountryCode());
        billingAddress.setPhone(sourceAddress.getPhone());

        billingAddress.custom.txLastNameKana = sourceAddress.custom.txLastNameKana;
        billingAddress.custom.txFirstNameKana = sourceAddress.custom.txFirstNameKana;
        //ワンタイムパスワードで認証されたメアドを設定
        cart.setCustomerEmail(session.forms.formlp.profile.customer.email.value);

        //【FFHC v1.0】 x.x.x. 決済導線見直し　End.

        cart.calculate();
        cart.validateForCheckout();

    	for (var it = cart.object.getAllProductLineItems().iterator(); it.hasNext();){
    		var productInCart = it.next();
    		if(productInCart.product != null){
    			//オプションを持つ商品かどうか
    			if(productInCart.getOptionProductLineItems().length > 0){
    				//定期商品がある場合は、定期間隔オプションの値を商品に設定
    				var options = productInCart.getOptionProductLineItems().iterator();
    				var option;
    				while(options.hasNext()){
    					option = options.next();
    					if(option.getOptionID() == 'txSubscOptPeriod'){
    						//TODO:代理で詳細に指定されている場合の考慮
    						productInCart.custom.txTeikiKind = '2';
    						productInCart.custom.txTeikiCycleMonInterval=option.getOptionValueID();
    					}
    				}
    			}else{
    				//アップセル商品で定期間隔オプション設定ありの場合、オプション商品以外にもtxSubscOptPeriodが設定されるため初期化
    				productInCart.custom.txTeikiKind = null;
    				productInCart.custom.txTeikiCycleMonInterval = null;
    			}

    			////定期商品を含むかどうか
    			//if(!productInCart.bonusProductLineItem && productInCart.product.custom.txShippingProductType.value == '2'){
    			//	subscList.push(productInCart);
    			//}

    			//日時指定不可商品がカートにある場合
    			//if(productInCart.product.custom.txHideDelivedateSelect){
    			//	hideDelivedateSelect = true;
    			//}
    		}
    	}



    });
}

exports.Show = guard.ensure(['get'], show);

exports.FormLpForm = guard.ensure(['post', 'https', 'csrf'], formLpForm);
exports.OrderConfirmation = guard.ensure(['post', 'https', 'csrf'], formLpForm);
