package org.mufg.bk.sample;

import java.io.Serializable;

public class SampleServiceOutput implements Serializable {

  private static final long serialVersionUID = 1L;

  private String sampleOutputMessage;

  public String getSampleOutputMessage() {
    return sampleOutputMessage;
  }

  public void setSampleOutputMessage(String sampleOutputMessage) {
    this.sampleOutputMessage = sampleOutputMessage;
  }
}
