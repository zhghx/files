package org.mufg.bk.sample;

import java.io.Serializable;

public class SampleServiceInput implements Serializable {

  private static final long serialVersionUID = 1L;

  private String sampleInputMessage;

  public String getSampleInputMessage() {
    return sampleInputMessage;
  }

  public void setSampleInputMessage(String sampleInputMessage) {
    this.sampleInputMessage = sampleInputMessage;
  }
}
