package org.mufg.bk.sample;

public interface SampleService {

    SampleServiceOutput execute(SampleServiceInput input);
}
