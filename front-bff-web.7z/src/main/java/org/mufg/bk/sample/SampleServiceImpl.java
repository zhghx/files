package org.mufg.bk.sample;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;

@Transactional
@ApplicationScoped
public class SampleServiceImpl implements SampleService {

    public SampleServiceOutput execute(SampleServiceInput input) {
        SampleServiceOutput sampleServiceOutput = new SampleServiceOutput();
        sampleServiceOutput.setSampleOutputMessage("Hello World");
        return sampleServiceOutput;
    }
}
