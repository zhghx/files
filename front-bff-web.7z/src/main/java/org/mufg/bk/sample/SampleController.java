package org.mufg.bk.sample;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/hello")
public class SampleController {

    private SampleService sampleService;

    public SampleController() {

    }

    @Inject
    public SampleController(SampleService sampleService) {
        this.sampleService = sampleService;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public SampleServiceOutput hello(@BeanParam SampleBeanParam sampleBeanParam) {
        SampleServiceInput sampleServiceInput = new SampleServiceInput();
        return sampleService.execute(sampleServiceInput);
    }
}