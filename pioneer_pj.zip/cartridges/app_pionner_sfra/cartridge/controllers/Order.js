'use strict';

/**
 * @namespace Order
 */

var server = require('server');

var BasketMgr = require("dw/order/BasketMgr");
var Resource = require('dw/web/Resource');
var URLUtils = require('dw/web/URLUtils');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var lpformHelpers = require("*/cartridge/scripts/lpform/lpformHelpers");
var Transaction = require("dw/system/Transaction");

server.extend(module.superModule);

server.append('Confirm', function (req, res, next) {
    var tempProducts = req.session.privacyCache.get("tempProducts");
    // var basket = req.session.privacyCache.get("basket");
    var currentBasket = BasketMgr.getCurrentOrNewBasket();
    if (tempProducts) {
        Transaction.wrap(function () {
            lpformHelpers.addCart(currentBasket, tempProducts);
        });
    }
    next();
});

module.exports = server.exports();
