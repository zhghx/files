"use strict";

/**
 * @namespace CheckoutServices
 */

var server = require("server");

var cache = require("*/cartridge/scripts/middleware/cache");
var consentTracking = require("*/cartridge/scripts/middleware/consentTracking");
var pageMetaData = require("*/cartridge/scripts/middleware/pageMetaData");
var COHelpers = require("*/cartridge/scripts/checkout/checkoutHelpers");
var collections = require("*/cartridge/scripts/util/collections");
var csrfProtection = require("*/cartridge/scripts/middleware/csrf");
var ShippingHelpers = require("*/cartridge/scripts/checkout/shippingHelpers");
var Locale = require("dw/util/Locale");
var Logger = require("dw/system/Logger");
var URLUtils = require("dw/web/URLUtils");
var CustomerMgr = require("dw/customer/CustomerMgr");
var Transaction = require("dw/system/Transaction");
var Resource = require("dw/web/Resource");
var cartHelper = require("*/cartridge/scripts/cart/cartHelpers");
var LpProductsModel = require("*/cartridge/models/lpmodel/lpproducts");
var LpShippingModel = require("*/cartridge/models/lpmodel/lpshipping");
var LpPaymentsModel = require("*/cartridge/models/lpmodel/lppayments");
var HashMap = require("dw/util/HashMap");
var lpformHelpers = require("*/cartridge/scripts/lpform/lpformHelpers");
var ArrayList = require("dw/util/ArrayList");
var BasketMgr = require("dw/order/BasketMgr");
var CartModel = require("*/cartridge/models/cart");
var ProductLineItemsModel = require("*/cartridge/models/productLineItems");
var basketCalculationHelpers = require("*/cartridge/scripts/helpers/basketCalculationHelpers");
var HookMgr = require("dw/system/HookMgr");
var PaymentMgr = require("dw/order/PaymentMgr");
var UUIDUtils = require("dw/util/UUIDUtils");
var HookManager = require("dw/system/HookMgr");
var ShippingMgr = require("dw/order/ShippingMgr");
var OrderMgr = require("dw/order/OrderMgr");
var hooksHelper = require("*/cartridge/scripts/helpers/hooks");
var validationHelpers = require("*/cartridge/scripts/helpers/basketValidationHelpers");
var addressHelpers = require("*/cartridge/scripts/helpers/addressHelpers");
var Currency = require('dw/util/Currency');

server.get("Test1", function (req, res, next) {
    res.render("/tanpin/demo1");
    return next();
});

/**
 * 単品のページ
 */
server.get("Show", function (req, res, next) {
    //START
    var currentBasket = BasketMgr.getCurrentOrNewBasket();
    //PARAM
    var pids = req.querystring.pids;
    var smethods = req.querystring.smethods;
    var currentLocale = Locale.getLocale(req.locale.id);
    let currentCustomer = req.currentCustomer.raw;
    var usingMultiShipping = req.session.privacyCache.get("usingMultiShipping");

    let isLoginRedirectUrl = null;
    if (req.currentCustomer.profile) {
        isLoginRedirectUrl = URLUtils.url('Home-Show').toString();
    }

    let sessionID = session.sessionID;
    let forms = session.forms;
    if(forms){
        let formId = forms.formId;
    }

    //SERVICE
    let lpProductsModel = new LpProductsModel(pids, 'JPY');
    let lpShippingModel = new LpShippingModel(smethods, lpProductsModel.allMoney);
    let lpPaymentsModel = new LpPaymentsModel(currentBasket, smethods);

    let lpForm = server.forms.getForm('lpform');

    //
    // this.on('route:BeforeComplete', function (req, res) {
    //     let lpForm = server.forms.getForm('lpform');
    //     if (!lpForm.valid) {
    //         res.setStatusCode(500);
    //     }
    //     res.json({ form: server.forms.getForm('practice') });
    // });


    // let lpForm = initLpFormData();
    res.render("/tanpin/lpbase", {
        products: lpProductsModel,
        shippingModels: lpShippingModel,
        billingModels: lpPaymentsModel,
        isLogin: req.currentCustomer.profile != null, //Checkout Login
        forms: {
            lpForm: lpForm,
        },
        isLoginRedirectUrl: isLoginRedirectUrl
    });
    next();
});

function checkoutLogin(req, res, next) {
}

function initLpFormData() {
    var lpForm = server.forms.getForm("lpform");
    lpForm.clear();
    //Product
    // let productCountList = (lpForm.productCountList.value =
    //     "701642853725:6|701642897767:6|701644389796:4");
    // //Account
    // lpForm.profileForm.customer.firstname.value = "佐藤";
    // lpForm.profileForm.customer.lastname.value = "清水2";
    // lpForm.profileForm.customer.email.value = "zhenghegong@128.com";
    // lpForm.profileForm.customer.emailconfirm.value = "zhg@126.com";
    // lpForm.profileForm.customer.phone.value = "9234567890";
    // lpForm.profileForm.customer.addtoemaillist.value = false;
    // lpForm.profileForm.login.password.value = "Microworld0301_";
    // lpForm.profileForm.login.passwordconfirm.value = "Microworld0301_";
    //
    // //Shipping
    // lpForm.shippingForm.shippingAddress.addressFields.firstName.value = "佐藤";
    // lpForm.shippingForm.shippingAddress.addressFields.lastName.value = "清水";
    // lpForm.shippingForm.shippingAddress.addressFields.address1.value = "住所 1";
    // lpForm.shippingForm.shippingAddress.addressFields.address2.value = "住所 2";
    // // lpForm.shippingForm.shippingAddress.addressFields.postalCode.value = "123-1234";
    // // lpForm.shippingForm.shippingAddress.addressFields.country.value = "JP";
    // // lpForm.shippingForm.shippingAddress.addressFields.city.value = "富山県";
    // // lpForm.shippingForm.shippingAddress.addressFields.states.stateCode.value = "富山県";
    // // lpForm.shippingForm.shippingAddress.addressFields.phone.value = "07083086495";
    // // lpForm.shippingForm.shippingAddress.shippingMethodID.value = "002";
    // // lpForm.shippingForm.shippingAddress.shippingAddressUseAsBillingAddress.value = "住所";
    //
    // //Payment
    // lpForm.billingForm.shippingAddressUseAsBillingAddress.value;
    // lpForm.billingForm.addressFields.firstName.value = "佐藤";
    // lpForm.billingForm.addressFields.lastName.value = "清水";
    // lpForm.billingForm.addressFields.address1.value = "住所 1";
    // lpForm.billingForm.addressFields.address2.value = "住所 2";
    // lpForm.billingForm.addressFields.postalCode.value = "123-1234";
    // lpForm.billingForm.addressFields.country.value = "JP";
    // lpForm.billingForm.addressFields.city.value = "富山県";
    // lpForm.billingForm.addressFields.states.stateCode.value = "富山県";
    // lpForm.billingForm.contactInfoFields.email.value = "zhg@126.com";
    // lpForm.billingForm.contactInfoFields.phone.value = "07083086495";
    // lpForm.billingForm.creditCardFields.cardNumber.value = "4111111111111111";
    // lpForm.billingForm.creditCardFields.securityCode.value = "123";

    return lpForm;
}

// /**
//  * 確認-注文
//  */
// server.post('SubmitLp', function (req, res, next) {
//     var lpForm = server.forms.getForm('lpform');
//     //Product
//     let productCountList = lpForm.productCountList.value;
//     //Account
//     let firstname = lpForm.profileForm.customer.firstname.value;
//     let lastname = lpForm.profileForm.customer.lastname.value;
//     let email = lpForm.profileForm.customer.email.value;
//     let emailconfirm = lpForm.profileForm.customer.emailconfirm.value;
//     let phone = lpForm.profileForm.customer.phone.value;
//     let addtoemaillist = lpForm.profileForm.customer.addtoemaillist.value;
//     let password = lpForm.profileForm.login.password.value;
//     let passwordconfirm = lpForm.profileForm.login.passwordconfirm.value;
//
//     var authComstomer;
//     let newAccount = false;
//
//     if (req.currentCustomer.profile) {
//         email = req.currentCustomer.profile.email;
//     }
//
//     let currentBasket = BasketMgr.getCurrentBasket();
//     if (!currentBasket || req.currentCustomer.profile == null) {
//         Transaction.wrap(function () {
//             authComstomer = CustomerMgr.getCustomerByLogin(email);
//             if (!authComstomer) {
//                 authComstomer = CustomerMgr.createCustomer(email, password);
//                 newAccount = true;
//             }
//         });
//
//         var customerLoginResult = Transaction.wrap(function () {
//             var authenticateCustomerResult = CustomerMgr.authenticateCustomer(email, password);
//             if (authenticateCustomerResult.status !== 'AUTH_OK') {
//                 var errorCodes = {
//                     ERROR_CUSTOMER_DISABLED: 'error.message.account.disabled',
//                     ERROR_CUSTOMER_LOCKED: 'error.message.account.locked',
//                     ERROR_CUSTOMER_NOT_FOUND: 'error.message.login.form',
//                     ERROR_PASSWORD_EXPIRED: 'error.message.password.expired',
//                     ERROR_PASSWORD_MISMATCH: 'error.message.password.mismatch',
//                     ERROR_UNKNOWN: 'error.message.error.unknown',
//                     default: 'error.message.login.form'
//                 };
//                 var errorMessageKey = errorCodes[authenticateCustomerResult.status] || errorCodes.default;
//                 var errorMessage = Resource.msg(errorMessageKey, 'login', null);
//                 return {
//                     error: true,
//                     errorMessage: errorMessage,
//                     status: authenticateCustomerResult.status,
//                     authenticatedCustomer: null
//                 };
//             }
//             return {
//                 error: false,
//                 errorMessage: null,
//                 status: authenticateCustomerResult.status,
//                 authenticatedCustomer: CustomerMgr.loginCustomer(authenticateCustomerResult, false)
//             };
//         });
//
//         authComstomer = customerLoginResult.authenticatedCustomer;
//
//         if (authComstomer) {
//             if (newAccount) {
//                 Transaction.wrap(function () {
//                     authComstomer.profile.firstName = firstname;
//                     authComstomer.profile.lastName = lastname;
//                     authComstomer.profile.phoneHome = phone;
//                     authComstomer.profile.email = email;
//                 });
//             }
//             req.session.privacyCache.set('args', null);
//         }
//         currentBasket = BasketMgr.getCurrentOrNewBasket();
//     } else {
//         authComstomer = currentBasket.customer;
//     }
//
//     //TODO Clean Cart
//     lpformHelpers.clearProductLineItem(currentBasket);
//
//     let productArray = new ArrayList();
//     let productIdAndCountSplit = new ArrayList(productCountList.split('|'));
//     Transaction.wrap(function () {
//         collections.forEach(productIdAndCountSplit, function (item) {
//             let productIdSplit = item.split(':');
//             let addProductForm = {};
//             addProductForm.form = {
//                 pid: productIdSplit[0],
//                 quantity: productIdSplit[1]
//             }
//             lpformHelpers.addProduct(currentBasket, addProductForm);
//         });
//     })
//
//     //Shipping
//     let firstNameShipping = lpForm.shippingForm.shippingAddress.addressFields.firstName.value;
//     let lastNameShipping = lpForm.shippingForm.shippingAddress.addressFields.lastName.value;
//     let address1Shipping = lpForm.shippingForm.shippingAddress.addressFields.address1.value;
//     let address2Shipping = lpForm.shippingForm.shippingAddress.addressFields.address2.value;
//     let postalCodeShipping = lpForm.shippingForm.shippingAddress.addressFields.postalCode.value;
//     let countryShipping = lpForm.shippingForm.shippingAddress.addressFields.country.value;
//     let cityShipping = lpForm.shippingForm.shippingAddress.addressFields.city.value;
//     let stateCodeShipping = lpForm.shippingForm.shippingAddress.addressFields.states.stateCode.value;
//     let phoneShipping = lpForm.shippingForm.shippingAddress.addressFields.phone.value;
//     let shippingMethodID = lpForm.shippingForm.shippingAddress.shippingMethodID.value;
//     let shippingAddressUseAsBillingAddress = lpForm.shippingForm.shippingAddress.shippingAddressUseAsBillingAddress.value;
//
//     var shippingData = {};
//     shippingData.address = {
//         firstName: firstNameShipping,
//         lastName: lastNameShipping,
//         address1: address1Shipping,
//         address2: address2Shipping,
//         city: cityShipping,
//         postalCode: postalCodeShipping,
//         countryCode: countryShipping,
//         phone: phoneShipping,
//     };
//     shippingData.shippingBillingSame = shippingAddressUseAsBillingAddress;
//
//     COHelpers.copyShippingAddressToShipment(
//         shippingData,
//         currentBasket.defaultShipment
//     );
//
//     Transaction.wrap(function () {
//         ShippingHelpers.selectShippingMethod(currentBasket.defaultShipment,
//             shippingMethodID,
//             ShippingMgr.getAllShippingMethods(),
//             shippingData.address);
//     });
//
//     //Payment
//     let shippingAddressUseAsBillingAddressPayment = lpForm.billingForm.shippingAddressUseAsBillingAddress.value;
//     let firstNamePayment = lpForm.billingForm.addressFields.firstName.value;
//     let lastNamePayment = lpForm.billingForm.addressFields.lastName.value;
//     let address1Payment = lpForm.billingForm.addressFields.address1.value;
//     let address2Payment = lpForm.billingForm.addressFields.address2.value;
//     let postalCodePayment = lpForm.billingForm.addressFields.postalCode.value;
//     let countryPayment = lpForm.billingForm.addressFields.country.value;
//     let cityPayment = lpForm.billingForm.addressFields.city.value;
//     let stateCodePayment = lpForm.billingForm.addressFields.states.stateCode.value;
//     let paymentMethodPayment = lpForm.billingForm.paymentMethod.value;
//     let emailPayment = lpForm.billingForm.contactInfoFields.email.value;
//     let phoneContactInfoPayment = lpForm.billingForm.contactInfoFields.phone.value;
//     COHelpers.copyBillingAddressToBasket(currentBasket.defaultShipment.shippingAddress, currentBasket);
//
//     // //Card
//     // let cardNumber = lpForm.billingForm.creditCardFields.cardNumber.value;
//     // let cardType = lpForm.billingForm.creditCardFields.cardType.value;
//     // let expirationMonth = lpForm.billingForm.creditCardFields.expirationMonth;
//     // let expirationYear = lpForm.billingForm.creditCardFields.expirationYear;
//     // let securityCode = lpForm.billingForm.creditCardFields.securityCode;
//
//     lpForm.billingForm.creditCardFields.cardNumber.value = lpForm.billingForm.creditCardFields.cardNumber.value.replace(/\s+/g, "");
//     //TODO
//     lpformHelpers.submitPayment(currentBasket, lpForm.billingForm, req);
//
//     res.redirect(URLUtils.url('Checkout-Begin').toString() + '?stage=placeOrder#placeOrder');
//     next();
// });

/**
 * 確認-注文
 */
server.post("SubmitLp", function (req, res, next) {
    var lpForm = server.forms.getForm("lpform");
    //Product
    let productCountList = lpForm.productCountList.value;
    //Account
    let firstname = lpForm.profileForm.customer.firstname.value;
    let lastname = lpForm.profileForm.customer.lastname.value;
    let email = lpForm.profileForm.customer.email.value;
    let emailconfirm = lpForm.profileForm.customer.emailconfirm.value;
    let phone = lpForm.profileForm.customer.phone.value;
    let addtoemaillist = lpForm.profileForm.customer.addtoemaillist.value;
    let password = lpForm.profileForm.login.password.value;
    let passwordconfirm = lpForm.profileForm.login.passwordconfirm.value;

    var authComstomer;
    let newAccount = false;

    //Shipping
    let firstNameShipping = lpForm.shippingForm.shippingAddress.addressFields.firstName.value;
    let lastNameShipping = lpForm.shippingForm.shippingAddress.addressFields.lastName.value;
    let address1Shipping = lpForm.shippingForm.shippingAddress.addressFields.address1.value;
    let address2Shipping = lpForm.shippingForm.shippingAddress.addressFields.address2.value;
    let postalCodeShipping = lpForm.shippingForm.shippingAddress.addressFields.postalCode.value;
    let countryShipping = lpForm.shippingForm.shippingAddress.addressFields.country.value;
    let cityShipping = lpForm.shippingForm.shippingAddress.addressFields.city.value;
    let stateCodeShipping = lpForm.shippingForm.shippingAddress.addressFields.states.stateCode.value;
    let phoneShipping = lpForm.shippingForm.shippingAddress.addressFields.phone.value;
    let shippingMethodID = lpForm.shippingForm.shippingAddress.shippingMethodID.value;
    let shippingAddressUseAsBillingAddress = lpForm.shippingForm.shippingAddress.shippingAddressUseAsBillingAddress.value;

    let productsItem = lpformHelpers.getProductsItemByPCL(productCountList);
    let allProductMoney = lpformHelpers.getAllProductMoney(productsItem, 'JPY');
    let shippingModel = lpformHelpers.getShippingMethodsById(shippingMethodID, allProductMoney);

    var shippingData = {
        shippingAddress: {
            address: {
                firstName: firstNameShipping,
                lastName: lastNameShipping,
                address1: address1Shipping,
                address2: address2Shipping,
                city: cityShipping,
                postalCode: postalCodeShipping,
                countryCode: countryShipping,
                phone: phoneShipping,
                stateCode: stateCodeShipping,
            },
        },
        shippingModel: shippingModel
    };
    shippingData.shippingAddress.shippingBillingSame = shippingAddressUseAsBillingAddress;

    //Payment
    let shippingAddressUseAsBillingAddressPayment = lpForm.billingForm.shippingAddressUseAsBillingAddress.value;
    let firstNamePayment = lpForm.billingForm.addressFields.firstName.value;
    let lastNamePayment = lpForm.billingForm.addressFields.lastName.value;
    let address1Payment = lpForm.billingForm.addressFields.address1.value;
    let address2Payment = lpForm.billingForm.addressFields.address2.value;
    let postalCodePayment = lpForm.billingForm.addressFields.postalCode.value;
    let countryPayment = lpForm.billingForm.addressFields.country.value;
    let cityPayment = lpForm.billingForm.addressFields.city.value;
    let stateCodePayment = lpForm.billingForm.addressFields.states.stateCode.value;
    let paymentMethodPayment = lpForm.billingForm.paymentMethod.value;
    let emailPayment = lpForm.billingForm.contactInfoFields.email.value;
    let phoneContactInfoPayment = lpForm.billingForm.contactInfoFields.phone.value;

    //Card
    let cardNumber = lpForm.billingForm.creditCardFields.cardNumber.value;
    let cardType = lpForm.billingForm.creditCardFields.cardType.value;
    let expirationMonth = lpForm.billingForm.creditCardFields.expirationMonth.value;
    let expirationYear = lpForm.billingForm.creditCardFields.expirationYear.value;
    let securityCode = lpForm.billingForm.creditCardFields.securityCode.value;

    var billingData = {
        billingAddress: {
            address: {
                firstName: firstNamePayment,
                lastName: lastNamePayment,
                address1: address1Payment,
                address2: address2Payment,
                city: cityPayment,
                postalCode: postalCodePayment,
                countryCode: countryPayment,
                phone: phoneContactInfoPayment,
                stateCode: stateCodePayment,
                emailPayment: emailPayment
            }
        },
        payment: {
            cardNumber: cardNumber,
            cardType: cardType,
            expirationMonth: expirationMonth,
            expirationYear: expirationYear,
            securityCode: securityCode
        }
    }

    //Order Summary
    let allPrice = allProductMoney.value + shippingModel.shippingCost.value;
    let totalQuantity = 0;
    collections.forEach(productsItem, function (product) {
        totalQuantity += (1 * product.selectedQuantity);
    });
    var orderData = {
        allProductMoney: allProductMoney,
        shippingModel: shippingModel,
        allPrice: allPrice,
        totalQuantity: totalQuantity,
        products: productsItem
    }

    res.render("lpcheckout/checkout", {
        shipping: shippingData,
        billing: billingData,
        order: orderData
    });
    next();
});

/**
 * 確認する
 */
server.post("PlaceOrder", function (req, res, next) {
    var lpForm = server.forms.getForm("lpform");
    //Product
    let productCountList = lpForm.productCountList.value;
    //Account
    let firstname = lpForm.profileForm.customer.firstname.value;
    let lastname = lpForm.profileForm.customer.lastname.value;
    let email = lpForm.profileForm.customer.email.value;
    let emailconfirm = lpForm.profileForm.customer.emailconfirm.value;
    let phone = lpForm.profileForm.customer.phone.value;
    let addtoemaillist = lpForm.profileForm.customer.addtoemaillist.value;
    let password = lpForm.profileForm.login.password.value;
    let passwordconfirm = lpForm.profileForm.login.passwordconfirm.value;

    var authComstomer;
    let newAccount = false;

    if (req.currentCustomer.profile) {
        email = req.currentCustomer.profile.email;
    }

    let currentBasket = BasketMgr.getCurrentBasket();
    if (!currentBasket || req.currentCustomer.profile == null) {
        Transaction.wrap(function () {
            authComstomer = CustomerMgr.getCustomerByLogin(email);
            if (!authComstomer) {
                authComstomer = CustomerMgr.createCustomer(email, password);
                newAccount = true;
            }
        });

        var customerLoginResult = Transaction.wrap(function () {
            var authenticateCustomerResult = CustomerMgr.authenticateCustomer(
                email,
                password
            );
            if (authenticateCustomerResult.status !== "AUTH_OK") {
                var errorCodes = {
                    ERROR_CUSTOMER_DISABLED: "error.message.account.disabled",
                    ERROR_CUSTOMER_LOCKED: "error.message.account.locked",
                    ERROR_CUSTOMER_NOT_FOUND: "error.message.login.form",
                    ERROR_PASSWORD_EXPIRED: "error.message.password.expired",
                    ERROR_PASSWORD_MISMATCH: "error.message.password.mismatch",
                    ERROR_UNKNOWN: "error.message.error.unknown",
                    default: "error.message.login.form",
                };
                var errorMessageKey =
                    errorCodes[authenticateCustomerResult.status] || errorCodes.default;
                var errorMessage = Resource.msg(errorMessageKey, "login", null);
                return {
                    error: true,
                    errorMessage: errorMessage,
                    status: authenticateCustomerResult.status,
                    authenticatedCustomer: null,
                };
            }
            return {
                error: false,
                errorMessage: null,
                status: authenticateCustomerResult.status,
                authenticatedCustomer: CustomerMgr.loginCustomer(
                    authenticateCustomerResult,
                    false
                ),
            };
        });

        authComstomer = customerLoginResult.authenticatedCustomer;

        if (authComstomer) {
            if (newAccount) {
                Transaction.wrap(function () {
                    authComstomer.profile.firstName = firstname;
                    authComstomer.profile.lastName = lastname;
                    authComstomer.profile.phoneHome = phone;
                    authComstomer.profile.email = email;
                });
            }
            req.session.privacyCache.set("args", null);
        }
        currentBasket = BasketMgr.getCurrentOrNewBasket();
    } else {
        authComstomer = currentBasket.customer;
    }

    //TODO Save temp product
    var tempProducts = lpformHelpers.getTempProducts(currentBasket);
    //TODO Clean Cart
    lpformHelpers.clearProductLineItem(currentBasket);
    //TODO Add Cart
    lpformHelpers.addCart(currentBasket, productCountList);

    //Shipping
    let firstNameShipping =
        lpForm.shippingForm.shippingAddress.addressFields.firstName.value;
    let lastNameShipping =
        lpForm.shippingForm.shippingAddress.addressFields.lastName.value;
    let address1Shipping =
        lpForm.shippingForm.shippingAddress.addressFields.address1.value;
    let address2Shipping =
        lpForm.shippingForm.shippingAddress.addressFields.address2.value;
    let postalCodeShipping =
        lpForm.shippingForm.shippingAddress.addressFields.postalCode.value;
    let countryShipping =
        lpForm.shippingForm.shippingAddress.addressFields.country.value;
    let cityShipping =
        lpForm.shippingForm.shippingAddress.addressFields.city.value;
    let stateCodeShipping =
        lpForm.shippingForm.shippingAddress.addressFields.states.stateCode.value;
    let phoneShipping =
        lpForm.shippingForm.shippingAddress.addressFields.phone.value;
    let shippingMethodID =
        lpForm.shippingForm.shippingAddress.shippingMethodID.value;
    let shippingAddressUseAsBillingAddress =
        lpForm.shippingForm.shippingAddress.shippingAddressUseAsBillingAddress
            .value;

    var shippingData = {};
    shippingData.address = {
        firstName: firstNameShipping,
        lastName: lastNameShipping,
        address1: address1Shipping,
        address2: address2Shipping,
        city: cityShipping,
        postalCode: postalCodeShipping,
        countryCode: countryShipping,
        phone: phoneShipping,
    };
    shippingData.shippingBillingSame = shippingAddressUseAsBillingAddress;

    COHelpers.copyShippingAddressToShipment(
        shippingData,
        currentBasket.defaultShipment
    );

    Transaction.wrap(function () {
        ShippingHelpers.selectShippingMethod(
            currentBasket.defaultShipment,
            shippingMethodID,
            ShippingMgr.getAllShippingMethods(),
            shippingData.address
        );
    });

    //Payment
    let shippingAddressUseAsBillingAddressPayment = lpForm.billingForm.shippingAddressUseAsBillingAddress.value;
    let firstNamePayment = lpForm.billingForm.addressFields.firstName.value;
    let lastNamePayment = lpForm.billingForm.addressFields.lastName.value;
    let address1Payment = lpForm.billingForm.addressFields.address1.value;
    let address2Payment = lpForm.billingForm.addressFields.address2.value;
    let postalCodePayment = lpForm.billingForm.addressFields.postalCode.value;
    let countryPayment = lpForm.billingForm.addressFields.country.value;
    let cityPayment = lpForm.billingForm.addressFields.city.value;
    let stateCodePayment = lpForm.billingForm.addressFields.states.stateCode.value;
    let paymentMethodPayment = lpForm.billingForm.paymentMethod.value;
    let emailPayment = lpForm.billingForm.contactInfoFields.email.value;
    let phoneContactInfoPayment = lpForm.billingForm.contactInfoFields.phone.value;
    COHelpers.copyBillingAddressToBasket(
        currentBasket.defaultShipment.shippingAddress,
        currentBasket
    );

    // //Card
    // let cardNumber = lpForm.billingForm.creditCardFields.cardNumber.value;
    // let cardType = lpForm.billingForm.creditCardFields.cardType.value;
    // let expirationMonth = lpForm.billingForm.creditCardFields.expirationMonth;
    // let expirationYear = lpForm.billingForm.creditCardFields.expirationYear;
    // let securityCode = lpForm.billingForm.creditCardFields.securityCode;

    lpForm.billingForm.creditCardFields.cardNumber.value =
        lpForm.billingForm.creditCardFields.cardNumber.value.replace(/\s+/g, "");
    //TODO
    lpformHelpers.submitPayment(currentBasket, lpForm.billingForm, req);

    //注文する
    //res.redirect(URLUtils.url('Checkout-Begin').toString() + '?stage=placeOrder#placeOrder');

    if (!currentBasket) {
        res.json({
            error: true,
            cartError: true,
            fieldErrors: [],
            serverErrors: [],
            redirectUrl: URLUtils.url("Cart-Show").toString(),
        });
        return next();
    }

    var validatedProducts = validationHelpers.validateProducts(currentBasket);
    if (validatedProducts.error) {
        res.json({
            error: true,
            cartError: true,
            fieldErrors: [],
            serverErrors: [],
            redirectUrl: URLUtils.url("Cart-Show").toString(),
        });
        return next();
    }

    if (req.session.privacyCache.get("fraudDetectionStatus")) {
        res.json({
            error: true,
            cartError: true,
            redirectUrl: URLUtils.url("Error-ErrorCode", "err", "01").toString(),
            errorMessage: Resource.msg("error.technical", "checkout", null),
        });

        return next();
    }

    var validationOrderStatus = hooksHelper(
        "app.validate.order",
        "validateOrder",
        currentBasket,
        require("*/cartridge/scripts/hooks/validateOrder").validateOrder
    );
    if (validationOrderStatus.error) {
        res.json({
            error: true,
            errorMessage: validationOrderStatus.message,
        });
        return next();
    }

    // Check to make sure there is a shipping address
    if (currentBasket.defaultShipment.shippingAddress === null) {
        res.json({
            error: true,
            errorStage: {
                stage: "shipping",
                step: "address",
            },
            errorMessage: Resource.msg("error.no.shipping.address", "checkout", null),
        });
        return next();
    }

    // Check to make sure billing address exists
    if (!currentBasket.billingAddress) {
        res.json({
            error: true,
            errorStage: {
                stage: "payment",
                step: "billingAddress",
            },
            errorMessage: Resource.msg("error.no.billing.address", "checkout", null),
        });
        return next();
    }

    // Calculate the basket
    Transaction.wrap(function () {
        basketCalculationHelpers.calculateTotals(currentBasket);
    });

    // Re-validates existing payment instruments
    var validPayment = COHelpers.validatePayment(req, currentBasket);
    if (validPayment.error) {
        res.json({
            error: true,
            errorStage: {
                stage: "payment",
                step: "paymentInstrument",
            },
            errorMessage: Resource.msg("error.payment.not.valid", "checkout", null),
        });
        return next();
    }

    // Re-calculate the payments.
    var calculatedPaymentTransactionTotal =
        COHelpers.calculatePaymentTransaction(currentBasket);
    if (calculatedPaymentTransactionTotal.error) {
        res.json({
            error: true,
            errorMessage: Resource.msg("error.technical", "checkout", null),
        });
        return next();
    }

    // Creates a new order.
    var order = COHelpers.createOrder(currentBasket);
    if (!order) {
        res.json({
            error: true,
            errorMessage: Resource.msg("error.technical", "checkout", null),
        });
        return next();
    }

    // Handles payment authorization
    var handlePaymentResult = COHelpers.handlePayments(order, order.orderNo);

    // Handle custom processing post authorization
    var options = {
        req: req,
        res: res,
    };
    var postAuthCustomizations = hooksHelper(
        "app.post.auth",
        "postAuthorization",
        handlePaymentResult,
        order,
        options,
        require("*/cartridge/scripts/hooks/postAuthorizationHandling")
            .postAuthorization
    );
    if (
        postAuthCustomizations &&
        Object.prototype.hasOwnProperty.call(postAuthCustomizations, "error")
    ) {
        res.json(postAuthCustomizations);
        return next();
    }

    if (handlePaymentResult.error) {
        res.json({
            error: true,
            errorMessage: Resource.msg("error.technical", "checkout", null),
        });
        return next();
    }

    var fraudDetectionStatus = hooksHelper(
        "app.fraud.detection",
        "fraudDetection",
        currentBasket,
        require("*/cartridge/scripts/hooks/fraudDetection").fraudDetection
    );
    if (fraudDetectionStatus.status === "fail") {
        Transaction.wrap(function () {
            OrderMgr.failOrder(order, true);
        });

        // fraud detection failed
        req.session.privacyCache.set("fraudDetectionStatus", true);

        res.json({
            error: true,
            cartError: true,
            redirectUrl: URLUtils.url(
                "Error-ErrorCode",
                "err",
                fraudDetectionStatus.errorCode
            ).toString(),
            errorMessage: Resource.msg("error.technical", "checkout", null),
        });

        return next();
    }

    // Places the order
    var placeOrderResult = COHelpers.placeOrder(order, fraudDetectionStatus);
    if (placeOrderResult.error) {
        res.json({
            error: true,
            errorMessage: Resource.msg("error.technical", "checkout", null),
        });
        return next();
    }

    if (req.currentCustomer.addressBook) {
        // save all used shipping addresses to address book of the logged in customer
        var allAddresses = addressHelpers.gatherShippingAddresses(order);
        allAddresses.forEach(function (address) {
            if (
                !addressHelpers.checkIfAddressStored(
                    address,
                    req.currentCustomer.addressBook.addresses
                )
            ) {
                addressHelpers.saveAddress(
                    address,
                    req.currentCustomer,
                    addressHelpers.generateAddressName(address)
                );
            }
        });
    }

    if (order.getCustomerEmail()) {
        COHelpers.sendConfirmationEmail(order, req.locale.id);
    }

    // Reset usingMultiShip after successful Order placement
    req.session.privacyCache.set("usingMultiShipping", false);

    // //TODO product recovery
    // lpformHelpers.addCart(currentBasket, tempProducts);
    //TODO product recovery
    req.session.privacyCache.set("tempProducts", tempProducts);
    // req.session.privacyCache.set("basket", currentBasket);

    // TODO: Exposing a direct route to an Order, without at least encoding the orderID
    //  is a serious PII violation.  It enables looking up every customers orders, one at a
    //  time.
    res.json({
        error: false,
        orderID: order.orderNo,
        orderToken: order.orderToken,
        continueUrl: URLUtils.url("Order-Confirm").toString(),
    });

    return next();
});

server.get(
    "ButtonShow",
    function (req, res, next) {
        var productHelper = require("*/cartridge/scripts/helpers/productHelpers");
        var showProductPageHelperResult = productHelper.showProductPage(
            req.querystring,
            req.pageMetaData
        );
        var productType = showProductPageHelperResult.product.productType;
        if (
            !showProductPageHelperResult.product.online &&
            productType !== "set" &&
            productType !== "bundle"
        ) {
            res.setStatusCode(404);
            res.render("error/notFound");
        } else {
            var pageLookupResult = productHelper.getPageDesignerProductPage(
                showProductPageHelperResult.product
            );

            if (
                (pageLookupResult.page && pageLookupResult.page.hasVisibilityRules()) ||
                pageLookupResult.invisiblePage
            ) {
                // the result may be different for another user, do not cache on this level
                // the page itself is a remote include and can still be cached
                res.cachePeriod = 0; // eslint-disable-line no-param-reassign
            }
            if (pageLookupResult.page) {
                res.page(
                    pageLookupResult.page.ID,
                    {},
                    pageLookupResult.aspectAttributes
                );
            } else {
                res.render("/tanpin/btnshow", {
                    product: showProductPageHelperResult.product,
                    addToCartUrl: showProductPageHelperResult.addToCartUrl,
                    resources: showProductPageHelperResult.resources,
                    breadcrumbs: showProductPageHelperResult.breadcrumbs,
                    canonicalUrl: showProductPageHelperResult.canonicalUrl,
                    schemaData: showProductPageHelperResult.schemaData,
                });
            }
        }
        next();
    },
    pageMetaData.computedPageMetaData
);

module.exports = server.exports();
