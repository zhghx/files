'use strict';

var ProductFactory = require('*/cartridge/scripts/factories/product');
var Resource = require('dw/web/Resource');
var URLUtils = require('dw/web/URLUtils');
var Transaction = require('dw/system/Transaction');
var CartModel = require('*/cartridge/models/cart');
var ProductLineItemsModel = require('*/cartridge/models/productLineItems');
var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
var PaymentManager = require('dw/order/PaymentMgr');
var HookManager = require('dw/system/HookMgr');
var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
var HookMgr = require('dw/system/HookMgr');
var PaymentMgr = require('dw/order/PaymentMgr');
var AccountModel = require('*/cartridge/models/account');
var OrderModel = require('*/cartridge/models/order');
var Locale = require('dw/util/Locale');
var hooksHelper = require('*/cartridge/scripts/helpers/hooks');
var validationHelpers = require('*/cartridge/scripts/helpers/basketValidationHelpers');
var ArrayList = require("dw/util/ArrayList");
var collections = require('*/cartridge/scripts/util/collections');
var Money = require('dw/value/Money');
var ShippingMgr = require('dw/order/ShippingMgr');
var HashSet = require('dw/util/HashSet');

function getProduct(pid, quantity) {
    var pliProduct = {
        pid: pid,
        quantity: quantity ? quantity : 1,
        options: null
    };
    return ProductFactory.get(pliProduct)
}

function getProductsItemByPID(pids) {
    let pidList = new ArrayList(String(pids).split('|'));
    var productList = new ArrayList();
    collections.forEach(pidList, function (productId) {
        productList.add(getProduct(productId));
    });
    return productList;
}

function getProductsItemByPCL(productCountList) {
    let productsItem = new ArrayList();
    let arrayList = new ArrayList(String(productCountList).split('|'));
    collections.forEach(arrayList, function (pidStr) {
        let strings = String(pidStr).split(':');
        productsItem.add(getProduct(strings[0], strings[1]));
    });
    return productsItem;
}

function getAllProductMoney(productsItem, currencyCode) {
    var allPrice = 0;
    let arrayList = new ArrayList(productsItem);
    collections.forEach(arrayList, function (product) {
        allPrice += (product.price.sales.value * product.selectedQuantity);
    });
    return new Money(allPrice, currencyCode);
}

function getShippingMethodsByName(smethods, allProductMoney) {
    let result = new ArrayList();
    let allShippingMethods = ShippingMgr.getAllShippingMethods();
    let smethodsSet = new HashSet(new ArrayList(String(smethods).split('|')));
    if (allShippingMethods && allShippingMethods.length > 0) {
        let applicableShippingMethodsArrayList = new ArrayList(allShippingMethods);
        collections.forEach(applicableShippingMethodsArrayList, function (item) {
            if (smethodsSet.contains(item.displayName)) {
                let shipping = {};
                shipping.shippingMethod = item;
                shipping.shippingCost = ShippingMgr.getShippingCost(item, allProductMoney);
                result.add(shipping);
            }
        });
    }
    return result;
}

function getShippingMethodsById(smId, allProductMoney) {
    let shipping = {};
    let allShippingMethods = ShippingMgr.getAllShippingMethods();
    if (allShippingMethods && allShippingMethods.length > 0) {
        let applicableShippingMethodsArrayList = new ArrayList(allShippingMethods);
        collections.forEach(applicableShippingMethodsArrayList, function (item) {
            if (item.ID == smId) {
                shipping.shippingMethod = item;
                shipping.shippingCost = ShippingMgr.getShippingCost(item, allProductMoney);
            }
        });
    }
    return shipping;
}

function submitPayment(currentBasket, paymentForm, req) {
    var viewData = {};
    // var paymentForm = server.forms.getForm('billing');

    // verify billing form data
    var billingFormErrors = COHelpers.validateBillingForm(paymentForm.addressFields);
    var contactInfoFormErrors = COHelpers.validateFields(paymentForm.contactInfoFields);

    var formFieldErrors = [];
    if (Object.keys(billingFormErrors).length) {
        formFieldErrors.push(billingFormErrors);
    } else {
        viewData.address = {
            firstName: {value: paymentForm.addressFields.firstName.value},
            lastName: {value: paymentForm.addressFields.lastName.value},
            address1: {value: paymentForm.addressFields.address1.value},
            address2: {value: paymentForm.addressFields.address2.value},
            city: {value: paymentForm.addressFields.city.value},
            postalCode: {value: paymentForm.addressFields.postalCode.value},
            countryCode: {value: paymentForm.addressFields.country.value}
        };

        if (Object.prototype.hasOwnProperty.call(paymentForm.addressFields, 'states')) {
            viewData.address.stateCode = {value: paymentForm.addressFields.states.stateCode.value};
        }
    }

    if (Object.keys(contactInfoFormErrors).length) {
        formFieldErrors.push(contactInfoFormErrors);
    } else {
        viewData.email = {
            value: paymentForm.contactInfoFields.email.value
        };

        viewData.phone = {value: paymentForm.contactInfoFields.phone.value};
    }

    var paymentMethodIdValue = paymentForm.paymentMethod.value;
    if (!PaymentManager.getPaymentMethod(paymentMethodIdValue).paymentProcessor) {
        throw new Error(Resource.msg(
            'error.payment.processor.missing',
            'checkout',
            null
        ));
    }

    var paymentProcessor = PaymentManager.getPaymentMethod(paymentMethodIdValue).getPaymentProcessor();
    var paymentFormResult;
    if (HookManager.hasHook('app.payment.form.processor.' + paymentProcessor.ID.toLowerCase())) {
        paymentFormResult = HookManager.callHook('app.payment.form.processor.' + paymentProcessor.ID.toLowerCase(),
            'processForm',
            req,
            paymentForm,
            viewData
        );
    } else {
        paymentFormResult = HookManager.callHook('app.payment.form.processor.default_form_processor', 'processForm');
    }

    if (paymentFormResult.error && paymentFormResult.fieldErrors) {
        formFieldErrors.push(paymentFormResult.fieldErrors);
    }

    if (formFieldErrors.length || paymentFormResult.serverErrors) {
        //TODO respond with form data and errors
        throw new Error('respond with form data and errors');
    }

    var billingData = paymentFormResult.viewData;

    if (!currentBasket) {
        //TODO currentBasket is null
        throw new Error('currentBasket is null');
    }

    var validatedProducts = validationHelpers.validateProducts(currentBasket);
    if (validatedProducts.error) {
        //TODO currentBasket is null
        throw new Error('currentBasket is validatedProducts.error');
    }

    var billingAddress = currentBasket.billingAddress;
    var paymentMethodID = billingData.paymentMethod.value;
    var result;

    Transaction.wrap(function () {
        if (!billingAddress) {
            billingAddress = currentBasket.createBillingAddress();
        }

        billingAddress.setFirstName(billingData.address.firstName.value);
        billingAddress.setLastName(billingData.address.lastName.value);
        billingAddress.setAddress1(billingData.address.address1.value);
        billingAddress.setAddress2(billingData.address.address2.value);
        billingAddress.setCity(billingData.address.city.value);
        billingAddress.setPostalCode(billingData.address.postalCode.value);
        if (Object.prototype.hasOwnProperty.call(billingData.address, 'stateCode')) {
            billingAddress.setStateCode(billingData.address.stateCode.value);
        }
        billingAddress.setCountryCode(billingData.address.countryCode.value);

        billingAddress.setPhone(billingData.phone.value);
        currentBasket.setCustomerEmail(billingData.email.value);
    });

    // if there is no selected payment option and balance is greater than zero
    if (!paymentMethodID && currentBasket.totalGrossPrice.value > 0) {
        //TODO if there is no selected payment option and balance is greater than zero
        throw new Error('if there is no selected payment option and balance is greater than zero');
    }

    var processor = PaymentMgr.getPaymentMethod(paymentMethodID).getPaymentProcessor();

    // check to make sure there is a payment processor
    if (!processor) {
        //TODO check to make sure there is a payment processor error
        throw new Error('check to make sure there is a payment processor error');
    }

    if (HookMgr.hasHook('app.payment.processor.' + processor.ID.toLowerCase())) {
        result = HookMgr.callHook('app.payment.processor.' + processor.ID.toLowerCase(),
            'Handle',
            currentBasket,
            billingData.paymentInformation,
            paymentMethodID,
            req
        );
    } else {
        result = HookMgr.callHook('app.payment.processor.default', 'Handle');
    }

    // need to invalidate credit card fields
    if (result.error) {
        //TODO need to invalidate credit card fields
        throw new Error(JSON.stringify(result.fieldErrors));
    }

    if (HookMgr.hasHook('app.payment.form.processor.' + processor.ID.toLowerCase())) {
        HookMgr.callHook('app.payment.form.processor.' + processor.ID.toLowerCase(),
            'savePaymentInformation',
            req,
            currentBasket,
            billingData
        );
    } else {
        HookMgr.callHook('app.payment.form.processor.default', 'savePaymentInformation');
    }

    // Calculate the basket
    Transaction.wrap(function () {
        basketCalculationHelpers.calculateTotals(currentBasket);
    });

    // Re-calculate the payments.
    var calculatedPaymentTransaction = COHelpers.calculatePaymentTransaction(
        currentBasket
    );

    if (calculatedPaymentTransaction.error) {
        //TODO calculatedPaymentTransaction.error
        throw new Error('calculatedPaymentTransaction.error');
    }

    var usingMultiShipping = req.session.privacyCache.get('usingMultiShipping');
    if (usingMultiShipping === true && currentBasket.shipments.length < 2) {
        req.session.privacyCache.set('usingMultiShipping', false);
        usingMultiShipping = false;
    }

    hooksHelper('app.customer.subscription', 'subscribeTo', [paymentForm.subscribe.checked, paymentForm.contactInfoFields.email.htmlValue], function () {
    });

    var currentLocale = Locale.getLocale(req.locale.id);

    var basketModel = new OrderModel(
        currentBasket,
        {usingMultiShipping: usingMultiShipping, countryCode: currentLocale.country, containerView: 'basket'}
    );

    var accountModel = new AccountModel(req.currentCustomer);
    var renderedStoredPaymentInstrument = COHelpers.getRenderedPaymentInstruments(
        req,
        accountModel
    );
}

function addCart(currentBasket, productCountList) {
    let productIdAndCountSplit = new ArrayList(productCountList.split("|"));
    Transaction.wrap(function () {
        collections.forEach(productIdAndCountSplit, function (item) {
            let productIdSplit = item.split(":");
            let addProductForm = {};
            addProductForm.form = {
                pid: productIdSplit[0],
                quantity: productIdSplit[1],
            };
            addProduct(currentBasket, addProductForm);
        });
    });
}

/**
 * addProduct
 */
function addProduct(currentBasket, req) {
    var previousBonusDiscountLineItems = currentBasket.getBonusDiscountLineItems();
    var productId = req.form.pid;
    var childProducts = Object.hasOwnProperty.call(req.form, 'childProducts')
        ? JSON.parse(req.form.childProducts)
        : [];
    var options = req.form.options ? JSON.parse(req.form.options) : [];
    var quantity;
    var result;
    var pidsObj;

    if (currentBasket) {
        Transaction.wrap(function () {
            if (!req.form.pidsObj) {
                quantity = parseInt(req.form.quantity, 10);
                result = cartHelper.addProductToCart(
                    currentBasket,
                    productId,
                    quantity,
                    childProducts,
                    options
                );
            } else {
                // product set
                pidsObj = JSON.parse(req.form.pidsObj);
                result = {
                    error: false,
                    message: Resource.msg('text.alert.addedtobasket', 'product', null)
                };

                pidsObj.forEach(function (PIDObj) {
                    quantity = parseInt(PIDObj.qty, 10);
                    var pidOptions = PIDObj.options ? JSON.parse(PIDObj.options) : {};
                    var PIDObjResult = cartHelper.addProductToCart(
                        currentBasket,
                        PIDObj.pid,
                        quantity,
                        childProducts,
                        pidOptions
                    );
                    if (PIDObjResult.error) {
                        result.error = PIDObjResult.error;
                        result.message = PIDObjResult.message;
                    }
                });
            }
            if (!result.error) {
                cartHelper.ensureAllShipmentsHaveMethods(currentBasket);
                basketCalculationHelpers.calculateTotals(currentBasket);
            }
        });
    }

    var quantityTotal = ProductLineItemsModel.getTotalQuantity(currentBasket.productLineItems);
    var cartModel = new CartModel(currentBasket);

    var urlObject = {
        url: URLUtils.url('Cart-ChooseBonusProducts').toString(),
        configureProductstUrl: URLUtils.url('Product-ShowBonusProducts').toString(),
        addToCartUrl: URLUtils.url('Cart-AddBonusProducts').toString()
    };

    var newBonusDiscountLineItem =
        cartHelper.getNewBonusDiscountLineItem(
            currentBasket,
            previousBonusDiscountLineItems,
            urlObject,
            result.uuid
        );
    if (newBonusDiscountLineItem) {
        var allLineItems = currentBasket.allProductLineItems;
        var collections = require('*/cartridge/scripts/util/collections');
        collections.forEach(allLineItems, function (pli) {
            if (pli.UUID === result.uuid) {
                Transaction.wrap(function () {
                    pli.custom.bonusProductLineItemUUID = 'bonus'; // eslint-disable-line no-param-reassign
                    pli.custom.preOrderUUID = pli.UUID; // eslint-disable-line no-param-reassign
                });
            }
        });
    }

    var reportingURL = cartHelper.getReportingUrlAddToCart(currentBasket, result.error);

    return {
        reportingURL: reportingURL,
        quantityTotal: quantityTotal,
        message: result.message,
        cart: cartModel,
        newBonusDiscountLineItem: newBonusDiscountLineItem || {},
        error: result.error,
        pliUUID: result.uuid,
        minicartCountOfItems: Resource.msgf('minicart.count', 'common', null, quantityTotal)
    };

}

function clearProductLineItem(currentBasket) {
    Transaction.wrap(function () {
        var productLineItems = currentBasket.getAllProductLineItems();
        for (var i = 0; i < productLineItems.length; i++) {
            var item = productLineItems[i];
            var shipmentToRemove = item.shipment;
            currentBasket.removeProductLineItem(item);
            if (shipmentToRemove.productLineItems.empty && !shipmentToRemove.default) {
                currentBasket.removeShipment(shipmentToRemove);
            }
        }
        basketCalculationHelpers.calculateTotals(currentBasket);
    });
}

function getTempProducts(currentBasket) {
    var tempList = new ArrayList();
    var productLineItems = currentBasket.getAllProductLineItems();
    for (var i = 0; i < productLineItems.length; i++) {
        var item = productLineItems[i];
        var productID = item.productID;
        var quantityValue = item.quantityValue;
        var productTmp = productID + ':' + quantityValue;
        tempList.add(productTmp);
    }
    return tempList.size() > 0 ? tempList.join('|') : '';
}

function recoveryProduct(currentBasket) {
    currentBasket.wrap(function () {
        var productLineItems = currentBasket.getAllProductLineItems();
        for (var i = 0; i < productLineItems.length; i++) {
            var item = productLineItems[i];
            var shipmentToRemove = item.shipment;
            currentBasket.removeProductLineItem(item);
            if (shipmentToRemove.productLineItems.empty && !shipmentToRemove.default) {
                currentBasket.removeShipment(shipmentToRemove);
            }
        }
        basketCalculationHelpers.calculateTotals(currentBasket);
    });
}

module.exports = {
    getShippingMethodsById: getShippingMethodsById,
    getShippingMethodsByName: getShippingMethodsByName,
    getAllProductMoney: getAllProductMoney,
    getProductsItemByPID: getProductsItemByPID,
    getProductsItemByPCL: getProductsItemByPCL,
    getProduct: getProduct,
    addProduct: addProduct,
    addCart: addCart,
    submitPayment: submitPayment,
    getTempProducts: getTempProducts,
    clearProductLineItem: clearProductLineItem
};
