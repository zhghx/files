'use strict';

var server = require('server');

var ArrayList = require('dw/util/ArrayList');
var HashSet = require('dw/util/HashSet');
var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
var collections = require('*/cartridge/scripts/util/collections');
var ShippingHelpers = require('*/cartridge/scripts/checkout/shippingHelpers');
var Logger = require('dw/system/Logger');


function getPayments(currentBasket, currentCustomer, currentLocale, usingMultiShipping, smethods) {

}

function getCreditCardExpirationYears() {
    // Get rid of this from top-level ... should be part of OrderModel???
    var currentYear = new Date().getFullYear();
    var creditCardExpirationYears = [];

    for (var j = 0; j < 10; j++) {
        creditCardExpirationYears.push(currentYear + j);
    }
    return creditCardExpirationYears;
}

function LpPayments(currentBasket, currentCustomer, currentLocale, usingMultiShipping, smethods) {
    this.paymentsObj = getPayments(currentBasket, currentCustomer, currentLocale, usingMultiShipping, smethods);
    this.expirationYears = getCreditCardExpirationYears();
}

module.exports = LpPayments;
