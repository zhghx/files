'use strict';

var ArrayList = require('dw/util/ArrayList');
var collections = require('*/cartridge/scripts/util/collections');
var productLineItem = require('*/cartridge/models/productLineItem/productLineItem');
var ProductMgr = require('dw/catalog/ProductMgr');
var PromotionMgr = require('dw/campaign/PromotionMgr');
var productHelper = require('*/cartridge/scripts/helpers/productHelpers');
var productTile = require('*/cartridge/models/product/productTile');
var ProductFactory = require('*/cartridge/scripts/factories/product');
var lpformHelpers = require('*/cartridge/scripts/lpform/lpformHelpers');

function getProducts(pids) {
    return lpformHelpers.getProductsItemByPID(pids);
}

function getMoney(item, currencyCode) {
    return lpformHelpers.getAllProductMoney(item, currencyCode);
}

function LpProducts(pids, currencyCode) {
    this.items = getProducts(pids);
    this.allMoney = getMoney(this.items, currencyCode);
}

module.exports = LpProducts;
