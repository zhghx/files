'use strict';

var lpformHelpers = require('*/cartridge/scripts/lpform/lpformHelpers');

function getShippingMethods(smethods, allProductMoney) {
    return lpformHelpers.getShippingMethodsByName(smethods, allProductMoney);
}

function LpShipping(smethods, money) {
    this.shippingMethods = getShippingMethods(smethods, money);
}

module.exports = LpShipping;
