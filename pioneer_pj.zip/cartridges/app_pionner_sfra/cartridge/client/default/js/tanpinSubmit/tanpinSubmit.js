'use strict';

var focusHelper = require('base/components/focus');
var cleave = require('base/components/cleave');

(function ($) {
    $('.place-order').click(function () {
        onPlaceOrder();
    });
    formatAllPrice();
}(jQuery));

function formatAllPrice() {
    formatPrice($('.sub-total'));
    formatPrice($('.shipping-total-cost'));
    formatPrice($('.grand-total-sum'));
    formatPrice($('.grand-total-price'));
    formatPrice($('.line-item-total-price-amount'));
}

function formatPrice(ele) {
    $(ele).each(function (index, el) {
        let price = $(el).text();
        $(el).text('¥ ' + Math.round(price).toLocaleString());
    });
}

function onPlaceOrder() {
    $.ajax({
        url: $('.place-order').data('action'),
        method: 'POST',
        success: function (data) {
            // enable the placeOrder button here
            $('body').trigger('checkout:enableButton', '.next-step-button button');
            if (data.error) {
                if (data.cartError) {
                    window.location.href = data.redirectUrl;
                }
            } else {
                var continueUrl = data.continueUrl;
                var urlParams = {
                    ID: data.orderID,
                    token: data.orderToken
                };

                continueUrl += (continueUrl.indexOf('?') !== -1 ? '&' : '?') +
                    Object.keys(urlParams).map(function (key) {
                        return key + '=' + encodeURIComponent(urlParams[key]);
                    }).join('&');

                window.location.href = continueUrl;
            }
        },
        error: function () {
            // enable the placeOrder button here
        }
    });
}

module.exports = exports;
