'use strict';

var focusHelper = require('base/components/focus');
var cleave = require('base/components/cleave');

(function ($) {
    // checkoutLogin();
    onProductCountInit();
    onProductCount();
    onLpSubmit();
    handleCreditCardNumber();
}(jQuery));

function checkoutLogin() {
    let isLogin = $('input[name=isLogin]').val();
    if (isLogin) {
        let redirectUrl = $('input[name=isLoginRedirectUrl]').val();
        if (redirectUrl !== 'null') {
            window.location.href = redirectUrl;
        }
    }
}

function handleCreditCardNumber() {
    cleave.handleCreditCardNumber('.cardNumber', '#cardType');
}

function onProductCountInit() {
    let products = [];
    $.each($('.product-info'), function (index, item) {
        let select = $(item).find('select');
        let pid = select.attr('data-pid');
        let selectProductCount = select.val() ? select.val() : 1;
        let productInfo = pid + ':' + selectProductCount;
        products.push(productInfo);
    });
    $('.lpform').find('.product-select-count').val(products.join('|'));
}

function onProductCount() {
    $('.quantity-form').find('.custom-select').on('change', function () {
        let products = [];
        $.each($('.product-info'), function (index, item) {
            let select = $(item).find('select');
            let pid = select.attr('data-pid');
            let productCount = select.val();
            let productInfo = pid + ':' + productCount;
            products.push(productInfo);
        });

        let pid = $(this).attr('data-pid');
        $('.lpform').find('.product-select-count').val(products.join('|'));
        //update
        let price = $('.pid-' + pid).find('.price').find('span.value').attr('content');
        let count = $(this).val();
        let allPrice = price * count;
        allPrice = '¥ ' + (allPrice).toLocaleString()
        $('.pid-' + pid).find('.line-item-total-price-amount').text(allPrice);
    });
}

function onLpSubmit() {
    $('.lp-submit').on('click', function () {
        let data = {};
        let value = $('.lpform').serializeArray();
        $.each(value, function (index, item) {
            data[item.name] = item.value;
        });
        let json = JSON.stringify(data);
        console.log('json : ', json);

        $('.lpform').submit();
    });
}

var exports = {};

module.exports = exports;
