'use strict';

/**
 * @namespace ContractTest
 */

var server = require('server');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

// Test URL
// https://zzgg-005.sandbox.us01.dx.commercecloud.salesforce.com/on/demandware.store/Sites-RefArch_Pioneer_Sun-Site/ja_JP/ContractTest-Get?contractNumber=10000002
server.get(
    'Get',
    consentTracking.consent,
    server.middleware.https,
    csrfProtection.generateToken,
    function (req, res, next) {

    var contractNumber = req.querystring.contractNumber;

    // パラメータを設定
    var reqObj = {
    		contractNumber : contractNumber
    };

    var apiManager = require('~/cartridge/scripts/api/ApiManager');
    var retObj = apiManager.test('ContractGet', reqObj);
    next();
    }
);

module.exports = server.exports();
