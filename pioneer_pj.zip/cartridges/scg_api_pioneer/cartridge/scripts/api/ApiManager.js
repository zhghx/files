'use strict';
/**
 * HTTPServiceCheckCustomerExist.js
 *
 * TELカナAPI
 *
 * Class HTTPServiceCheckCustomerExist
 */

 let Logger = require('dw/system/Logger');

let test = function (nameService, params) {

    let serviceName = require('~/cartridge/scripts/api/ConfigAPI')[nameService] || "";
    let serviceInstance = require(serviceName);
    let ApiService = serviceInstance.ApiService;

    let retObj = {};
    if(dw.system.Site.current.getCustomPreferenceValue('gmo_softbank_auth_mode_only')){
        retObj = ApiService.mockService(nameService, params);
    } else{
        retObj = {'result':'not mock'}
    }
    return retObj;
};

/* -----------Export APIManager Class---------------- */
module.exports.test = test;
