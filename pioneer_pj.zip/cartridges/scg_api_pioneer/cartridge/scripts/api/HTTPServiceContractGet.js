'use strict';
/**
 * Mock API
 */

let ApiService = (function(){
    let mockService = function(nameHTTPService, params){
        var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
        var myHTTPService = LocalServiceRegistry.createService(nameHTTPService, {
            createRequest : function (svc, params) {
                svc.setEncoding("UTF-8");
                svc.setRequestMethod("POST");
                svc.addHeader("Content-Type", "application/json; charset=UTF-8");
                return JSON.stringify(params);
            },
            parseResponse : function (svc, response) {
                return response;
            },
            mockCall : function (svc, requestJson) {

                let requestObj = JSON.parse(requestJson);

                let statusCode = 200;

                if(requestObj.contractNumber == '10000001'){
                    statusCode = 200;

                }else if(requestObj.contractNumber == '10000002'){
                    statusCode = 201;

                }else if(requestObj.contractNumber == '10000003'){
                    statusCode = 202;

                }else if(requestObj.contractNumber == '10000004'){
                    statusCode = 203;

                }else if(requestObj.contractNumber == '10000005'){
                    statusCode = 204;

                }

                return {
                    statusCode : statusCode,
                    statusMessage : "Success"
                };
            },
            filterLogMessage : function (msg) {
                return msg;
            }
        });

        return myHTTPService.call(params);

    }

    return {
        mockService:mockService
    }
})();

/* -----------Export HTTPServiceCheckProductExist Class---------------- */
module.exports.ApiService = ApiService;
