'use strict';
/**
 * Mock API
 */

let ApiService = (function(){
    let mockService = function(nameHTTPService, params){
        var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
        var myHTTPService = LocalServiceRegistry.createService(nameHTTPService, {
            createRequest : function (svc, params) {
                svc.setEncoding("UTF-8");
                svc.setRequestMethod("POST");
                svc.addHeader("Content-Type", "application/json; charset=UTF-8");
                return JSON.stringify(params);
            },
            parseResponse : function (svc, response) {
                return response;
            },
            mockCall : function (svc, requestObj) {
                var Site = require('dw/system/Site');

                let objResponse = {};
                objResponse.return_status = "00";

                return {
                    statusCode : 200,
                    statusMessage : "Success"
                };
            },
            filterLogMessage : function (msg) {
                return msg;
            }
        });

        return myHTTPService.call(params);

    }

    return {
        mockService:mockService
    }
})();

/* -----------Export HTTPServiceCheckProductExist Class---------------- */
module.exports.ApiService = ApiService;
