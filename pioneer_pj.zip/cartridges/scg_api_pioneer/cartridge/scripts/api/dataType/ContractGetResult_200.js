'use strict'
module.exports = new XML(
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Result>
  <Value name="result">1</Value>
  <Value name="errorMsg">エラー発生エラー発生</Value>
  <Value name="errorCode">ERR00011</Value>
</Result>
);
