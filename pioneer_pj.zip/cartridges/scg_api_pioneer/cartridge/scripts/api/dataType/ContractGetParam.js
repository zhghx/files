'use strict'
module.exports = new XML(
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<requests>
  <Value name="contractNumber"></Value>
</requests>
);
