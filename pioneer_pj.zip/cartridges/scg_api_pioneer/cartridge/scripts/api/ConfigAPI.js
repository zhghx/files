'use strict';
/**
 * ConfigAPI.js
 *
 * Array ConfigAPI
 *
 * @key: Name service on BM
 * @value: File path of the service API
 */
var ConfigAPI = [];

/* Protocol https */
ConfigAPI["CheckProductExist"] = "~/cartridge/scripts/api/HTTPServiceCheckProductExist";
ConfigAPI["ContractGet"] = "~/cartridge/scripts/api/HTTPServiceContractGet";

/** -----------Export ConfigAPI Array---------------- */
module.exports = ConfigAPI;
